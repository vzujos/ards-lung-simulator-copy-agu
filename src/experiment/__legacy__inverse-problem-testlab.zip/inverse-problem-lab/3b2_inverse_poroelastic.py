# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 14:30:27 2025

@author: angus
"""

from dolfin import *
import numpy as np
import dolfin, os


destination_folder = "./problem-3/"
if not os.path.isdir(destination_folder):
    os.mkdir(destination_folder)

#Define some dolfin parameters
dolfin.parameters["form_compiler"]["cpp_optimize"] = True
dolfin.parameters["form_compiler"]["representation"] = "uflacs"
dolfin.parameters["form_compiler"]["quadrature_degree"] = 4
dolfin.parameters["allow_extrapolation"] = True 
dolfin.parameters["form_compiler"]["optimize"] = True 

# Incompressible Neo-Hookean over a cube of side 100 mm
L = 100.0 # mm
Lx = L
Ly = L
Lz = L
# Load the mesh stored in an xdmf file
mesh = Mesh()
with XDMFFile(destination_folder+"a_forward-geometry.xdmf") as infile:
    infile.read(mesh)

# Path towards the current porosity data
porosity_path = destination_folder+"a_phi.xml.gz"

if os.path.isfile(porosity_path):
    print("Porosity file found")
else:
    print("Porosity file not found")
    
# Define porosity as MeshFunctions
phi = MeshFunction("double", mesh, porosity_path)
    
# Code for C++ evaluation of permeability (conductivity)
porosity_code = """
        
#include <pybind11/pybind11.h>
#include <pybind11/eigen.h>
namespace py = pybind11;
        
#include <dolfin/function/Expression.h>
#include <dolfin/mesh/MeshFunction.h>
        
class Porosity : public dolfin::Expression
{
 public:
        
     // Create expression with 1 component
     Porosity() : dolfin::Expression(1) {}
     
     // Function for evaluating expression on each cell
     void eval(Eigen::Ref<Eigen::VectorXd> values, Eigen::Ref<const Eigen::VectorXd> x, const ufc::cell& cell) const override
     {
      const uint cell_index = cell.index;
      values[0] = (*phi)[cell_index];
      }
        
     // The data stored in mesh functions
          std::shared_ptr<dolfin::MeshFunction<double>> phi;
        
 };
        
 PYBIND11_MODULE(SIGNATURE, m)
{
py::class_<Porosity, std::shared_ptr<Porosity>, dolfin::Expression>
(m, "Porosity")
.def(py::init<>())
.def_readwrite("phi", &Porosity::phi);
}
        
"""
        
phi_code = dolfin.CompiledExpression(compile_cpp_code(porosity_code).Porosity(),
                               phi=phi, degree=0)
    
phi = phi_code[0]
        

# ---------------------- function spaces ----------------------
P2 = VectorElement("Lagrange", mesh.ufl_cell(), 2)
P1 = FiniteElement("CG", mesh.ufl_cell(), 1)
TH = P2*P1 # Taylor-Hood
W = FunctionSpace(mesh, TH)

# Functions for displacement and pressure
w = dolfin.Function(W)
u, p = dolfin.split(w)

# Test and trial functions
_u, _p = dolfin.TestFunctions(W)
du = dolfin.TrialFunction(W) 

# ---------------------- material parameters ----------------------
mu = 1.66 # (kPa) | Lame constant | Reference Concha et al. 2018 
kappa = 1e5 # Permeability, defined in AR&H (2022)

# gravity parameters
rho_t = Constant(1.0e-6)  # (tissue) Water density  kg/mm3
rho_a = Constant(1.0e-9) # (air) Air density kg/mm3 
g = Constant((0.0, -9810, 0.0))  # Gravity vector in mm/s2 (downwards)

# Define a placeholder for a (potentially) spatially variable phi0 
G = FunctionSpace(mesh,"CG",1)
        
# ---------------------- boundary markers ----------------------
# Generate boundaries for the bottom face
boundaries = MeshFunction("size_t", mesh, mesh.topology().dim()-1)
boundaries.set_all(0)

#Bottom face
class YMin(SubDomain):
    def inside(self, x, on_boundary):
        return near(x[1], 0.0)

# Marking the faces as min and max
ymin = YMin()
ymin.mark(boundaries, 1)

# Define geometric measures and limit quadrature degree
dx = dolfin.Measure("dx", domain=mesh)
ds = Measure('ds', domain=mesh, subdomain_data=boundaries)
dx = dx(degree=3)
ds = ds(degree=3)
    
dolfin.info("Num DOFs {}".format(W.dim()))

# ---------------------- kinematics & constitutive ----------------------
def stress_bir2019(u, p,c=0.3567,beta=1.075,alpha=1.0):
    I = Identity(3)
    F = inv(I + grad(u))
    F *= alpha 
    C=variable(F.T*F)
    I1C=variable(tr(C))
    I2C=0.5*((tr(C)**2)-tr(C*C))
    I3C=variable(det(C))
    J=variable(sqrt(I3C))
    I1raya=I1C*pow(I3C,-1/3)
    psi=c*(I1C-3)  +  (c/beta)*(pow(I3C,-beta)-1)+(278.2/1000)*pow((pow(I3C,-1/3)*I1C-3),3)+(5.766/1000)*pow((pow(I3C,1/3)-1),6)
    S=2*diff(psi,C)
    sigma = 1./J*F*S*F.T - p*I # Akin to what we had for P
    
    return sigma ,F, J

sigma,F,J = stress_bir2019(u,p)

R = (J-phi)*rho_t + phi*rho_a

# Flux
#Q = J*Constant(kappa)*inv(F)*inv(F).T*grad(p)
q = -kappa*(grad(p)+rho_a*g)

# Residual: mechanical + body force + incompressibility (pressure) equation
#Res = inner(P, grad(_u))*dx - R*dot(g, _u)*dx + (J - 1.0)*_p*dx + inner(Q, grad(_p))*dx
Res = inner(sigma, grad(_u))*dx - R*dot(g, _u)*dx + inner(q, grad(_p))*dx

# Jacobian (derivative of residual w.r.t the mixed unknown w in direction du)
Jac = derivative(Res, w, du)




bc_ymin_y = DirichletBC(W.sub(0), Constant((0.0,0.0,0.0)), boundaries, 1)

# construir lista final de BCs (quita el corner BC anterior si lo tenías)
bcs = [bc_ymin_y]

# Build the problem
problem = NonlinearVariationalProblem(Res, w, bcs, Jac)
solver = NonlinearVariationalSolver(problem)

# First solver parameter definition
solver_parameters = {"nonlinear_solver":"snes",
                     "snes_solver":{"linear_solver":"lu",
                                    "relative_tolerance":1e-6,
                                    "absolute_tolerance":1e-8,
                                    "maximum_iterations":60,
                                    "line_search":"bt",
                                    "report":True,
                                    "error_on_nonconvergence":True,
                                    "preconditioner":"default"}
                     }

# First solver parameter definition
solver.parameters.update(solver_parameters)
# Solve 
solver.solve()

# Define output spaces
T = dolfin.TensorFunctionSpace(mesh, "CG", 1) 
Q = dolfin.FunctionSpace(mesh, 'CG', 1)
V = dolfin.VectorFunctionSpace(mesh, "Lagrange", 1)  ##

# Extract solution components
u, p = w.split()
u.rename("Displacement", "")
p.rename("Pressure", "")

# Kinematics
I = Identity(len(u))
F = inv(I + grad(u))
C = F.T*F
J = det(F)

# Compute the variables again (why?)
P, F, J = stress_bir2019(u,p)

# Convert to Cauchy stress for von Mises
sigma = (1.0/J) * P * F.T

# Determine hydrostatic pressure
P_hyd = -1./3.*tr(sigma)*10.1972 # in cmH2O
P_hyd_ = project(P_hyd, Q)
P_hyd_.rename("Hydrostatic pressure (cmH2O)","")

# Von Mises stress
von_mises = sqrt(
    0.5 * ((sigma[0,0]-sigma[1,1])**2
           + (sigma[1,1]-sigma[2,2])**2
           + (sigma[2,2]-sigma[0,0])**2)
    + 3.0*(sigma[0,1]**2 + sigma[1,2]**2 + sigma[2,0]**2)
)
VM = project(von_mises, Q)   # scalar CG field
VM.rename("Von Mises stress", "")

# Eulerian porosity
phi0 = phi + 1 - J
phi_out = project(phi0, Q)
phi_out.rename("Phi_0","")

# Jacobian
Jproj = project(J, Q)
Jproj.rename("Jacobian", "")

# Export to XDMF
t = 0.0 # Dummy
xdmf = XDMFFile(mesh.mpi_comm(), destination_folder+"b_output-fields.xdmf")
xdmf.parameters["flush_output"] = True
xdmf.parameters["functions_share_mesh"] = True

xdmf.write(VM,t)
xdmf.write(P_hyd_,t)
xdmf.write(u,t)
xdmf.write(p,t)
xdmf.write(phi_out,t)
xdmf.write(Jproj,t)




ALE.move(mesh,u)
with XDMFFile(destination_folder+"b_recovered-geometry.xdmf") as xdmf:
    xdmf.write(mesh)