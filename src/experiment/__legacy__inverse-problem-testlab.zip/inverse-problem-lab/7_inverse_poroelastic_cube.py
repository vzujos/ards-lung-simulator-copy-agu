# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 14:30:27 2025

@author: angus
"""

from dolfin import *
import numpy as np
import dolfin, os


destination_folder = "./problem-7/"
if not os.path.isdir(destination_folder):
    os.mkdir(destination_folder)

#Define some dolfin parameters
dolfin.parameters["form_compiler"]["cpp_optimize"] = True
dolfin.parameters["form_compiler"]["representation"] = "uflacs"
dolfin.parameters["form_compiler"]["quadrature_degree"] = 4
dolfin.parameters["allow_extrapolation"] = True 
dolfin.parameters["form_compiler"]["optimize"] = True 


# Incompressible Neo-Hookean over a cube of side 200 mm

# ---------------------- geometry / mesh ----------------------
L = 100.0 # mm
Lx = L
Ly = L
Lz = L
mean_phi = 0.5 # Initial porosity = 0.5, spatially homogeneous

# mesh subdivisions (adjust for accuracy / speed)
n = 8
mesh = BoxMesh(Point(0.0, 0.0, 0.0), Point(Lx, Ly, Lz), n, n, n)


# ---------------------- function spaces ----------------------
P2 = VectorElement("Lagrange", mesh.ufl_cell(), 2)
P1 = FiniteElement("CG", mesh.ufl_cell(), 1)
TH = P2*P1 # Taylor-Hood
W = FunctionSpace(mesh, TH)

# Functions for displacement and pressure
w = dolfin.Function(W)
u, p = dolfin.split(w)

# Test and trial functions
_u, _p = dolfin.TestFunctions(W)
du = dolfin.TrialFunction(W) 

# ---------------------- material parameters ----------------------
mu = 1.66 # (kPa) | Lame constant | Reference Concha et al. 2018 
kappa = 1e5 # Permeability, defined in AR&H (2022)

# gravity parameters
rho_t = Constant(1.0e-6)  # (tissue) Water density  kg/mm3
rho_a = Constant(1.0e-9) # (air) Air density kg/mm3 
g = Constant((0.0, -9810, 0.0))  # Gravity vector in mm/s2 (downwards)

# Define a placeholder for a (potentially) spatially variable phi0 
G = FunctionSpace(mesh,"CG",1)
phi =interpolate(Constant(mean_phi),G)
        
# ---------------------- boundary markers ----------------------
from dolfin import MeshFunction, Measure

# Generate boundaries for the bottom face
boundaries = MeshFunction("size_t", mesh, mesh.topology().dim()-1)
boundaries.set_all(0)

#Bottom face
class YMin(SubDomain):
    def inside(self, x, on_boundary):
        return near(x[1], 0.0)
    
# Create boundary mesh function
boundaries = MeshFunction("size_t", mesh, mesh.topology().dim() - 1)
boundaries.set_all(0)
tol = 1e-8

# Define subdomains for the four faces
class XMin(SubDomain):   # YZ plane at x=0
    def inside(self, x, on_boundary):
        return on_boundary and near(x[0], 0.0, tol)

class XMax(SubDomain):   # YZ plane at x=Lx
    def inside(self, x, on_boundary):
        return on_boundary and near(x[0], Lx, tol)

class ZMin(SubDomain):   # XY plane at z=0
    def inside(self, x, on_boundary):
        return on_boundary and near(x[2], 0.0, tol)

class ZMax(SubDomain):   # XY plane at z=Lz
    def inside(self, x, on_boundary):
        return on_boundary and near(x[2], Lz, tol)

# Mark the faces
YMin().mark(boundaries, 1)
XMin().mark(boundaries, 2)
XMax().mark(boundaries, 3)
ZMin().mark(boundaries, 4)
ZMax().mark(boundaries, 5)

# Define boundary measure
ds = Measure('ds', domain=mesh, subdomain_data=boundaries)

# Quick diagnostic print
print("Boundary markers (should be 2–5):", np.unique(boundaries.array()))
for i in [1, 2, 3, 4, 5]:
    print(f"  Facets with id {i}: {np.sum(boundaries.array() == i)}")

# Define geometric measures and limit quadrature degree
dx = dolfin.Measure("dx", domain=mesh)
ds = Measure('ds', domain=mesh, subdomain_data=boundaries)
dx = dx(degree=3)
ds = ds(degree=3)
    
dolfin.info("Num DOFs {}".format(W.dim()))

# ---------------------- kinematics & constitutive ----------------------
def stress_bir2019(u, p,c=0.3567,beta=1.075,alpha=1.0):
    I = Identity(3)
    F = inv(I + grad(u))
    F *= alpha 
    C=variable(F.T*F)
    I1C=variable(tr(C))
    I2C=0.5*((tr(C)**2)-tr(C*C))
    I3C=variable(det(C))
    J=variable(sqrt(I3C))
    I1raya=I1C*pow(I3C,-1/3)
    psi=c*(I1C-3)  +  (c/beta)*(pow(I3C,-beta)-1)+(278.2/1000)*pow((pow(I3C,-1/3)*I1C-3),3)+(5.766/1000)*pow((pow(I3C,1/3)-1),6)
    S=2*diff(psi,C)
    sigma = 1./J*F*S*F.T - p*I # Akin to what we had for P
    
    return sigma ,F, J

sigma,F,J = stress_bir2019(u,p)

# Density
R = (J-phi)*rho_t + phi*rho_a

# Flux
q = -kappa*(grad(p)+rho_a*g)

# Pressure over walls
_, y_min, _ = mesh.coordinates().min(axis=0) 
_, y_max, _ = mesh.coordinates().max(axis=0) # 

# Define the pressures being applied
dp = -5.0 # in (cmH2O)
p_top = 0.0 # transform cmH2O into kPa
p_bottom = dp / 10.1972 # Forced to be zero

# Note that the lung is 'upside down' and the ventral region occurs
# at y_min and and the dorsal at y_max.
p_expr = Expression(
    "p_top + (p_bottom - p_top)*(x[1]-y_min)/(y_max - y_min)",
    degree=1,
    p_top=p_top,
    p_bottom=p_bottom,
    y_min=y_min,
    y_max=y_max
) 

Qp = FunctionSpace(mesh,"CG",1)
p_test = interpolate(p_expr, Qp)

with XDMFFile(mesh.mpi_comm(), destination_folder+"pressure-field.xdmf") as xdmf:
    xdmf.write(p_test, 0.0)

# Define a normal function
n = FacetNormal(mesh)

F2 = dolfin.inner(p_test*n,_u)* dolfin.ds(subdomain_data=boundaries,
                               subdomain_id=2)
F3 = dolfin.inner(p_test*n,_u)* dolfin.ds(subdomain_data=boundaries,
                               subdomain_id=3)
F4 = dolfin.inner(p_test*n,_u)* dolfin.ds(subdomain_data=boundaries,
                               subdomain_id=4)
F5 = dolfin.inner(p_test*n,_u)* dolfin.ds(subdomain_data=boundaries,
                               subdomain_id=5)


# Residual: mechanical + body force + incompressibility (pressure) equation
Res = inner(sigma, grad(_u))*dx - R*dot(g, _u)*dx + inner(q, grad(_p))*dx

Res += F2 + F3 + F4 + F5

# Jacobian (derivative of residual w.r.t the mixed unknown w in direction du)
Jac = derivative(Res, w, du)

# Define the boundary conditions
tol = 1e-6

# Lock one corner (x=0, y=0, z=0) in x and z to avoid rigid body motion 
bc_ymin_y = DirichletBC(W.sub(0), Constant((0.0,0.0,0.0)), boundaries, 1)

# construir lista final de BCs (quita el corner BC anterior si lo tenías)
bcs = [bc_ymin_y]

# Build the problem
problem = NonlinearVariationalProblem(Res, w, bcs, Jac)
solver = NonlinearVariationalSolver(problem)

# First solver parameter definition
solver_parameters = {"nonlinear_solver":"snes",
                     "snes_solver":{"linear_solver":"lu",
                                    "relative_tolerance":1e-6,
                                    "absolute_tolerance":1e-8,
                                    "maximum_iterations":60,
                                    "line_search":"bt",
                                    "report":True,
                                    "error_on_nonconvergence":True,
                                    "preconditioner":"default"}
                     }

# First solver parameter definition
solver.parameters.update(solver_parameters)
# Solve 
solver.solve()

# Define output spaces
T = dolfin.TensorFunctionSpace(mesh, "CG", 1) 
Q = dolfin.FunctionSpace(mesh, 'CG', 1)
V = dolfin.VectorFunctionSpace(mesh, "Lagrange", 1)  ##

# Extract solution components
u, p = w.split()
u.rename("Displacement", "")
p.rename("Pressure", "")

# Kinematics
I = Identity(len(u))
F = inv(I + grad(u))
C = F.T*F
J = det(F)

# Compute the variables again (why?)
P, F, J = stress_bir2019(u,p)

# Convert to Cauchy stress for von Mises
sigma = (1.0/J) * P * F.T

# Determine hydrostatic pressure
P_hyd = -1./3.*tr(sigma)*10.1972 # in cmH2O
P_hyd_ = project(P_hyd, Q)
P_hyd_.rename("Hydrostatic pressure (cmH2O)","")

# Von Mises stress
von_mises = sqrt(
    0.5 * ((sigma[0,0]-sigma[1,1])**2
           + (sigma[1,1]-sigma[2,2])**2
           + (sigma[2,2]-sigma[0,0])**2)
    + 3.0*(sigma[0,1]**2 + sigma[1,2]**2 + sigma[2,0]**2)
)
VM = project(von_mises, Q)   # scalar CG field
VM.rename("Von Mises stress", "")

# Original (?) porosity
phi0 = phi + 1 - J
phi0_out = project(phi0, Q)
phi0_out.rename("Phi_0","")

# Eulerian porosity
phi_out = project(phi, Q)
phi_out.rename("Phi","")

# Delta Gas fraction
dgf = phi - phi0 # Tiene sentido? Quizás no
dgf_out = project(dgf, Q)
dgf_out.rename("Delta Gas Fraction","")

# Jacobian
Jproj = project(J, Q)
Jproj.rename("Jacobian", "")

# Export to XDMF
t = 0.0 # Dummy
xdmf = XDMFFile(mesh.mpi_comm(), destination_folder+"output-fields.xdmf")
xdmf.parameters["flush_output"] = True
xdmf.parameters["functions_share_mesh"] = True

xdmf.write(VM,t)
xdmf.write(P_hyd_,t)
xdmf.write(u,t)
xdmf.write(p,t)
xdmf.write(phi0_out,t)
xdmf.write(phi_out,t)
xdmf.write(Jproj,t)
xdmf.write(dgf_out,t)

ALE.move(mesh,u)
with XDMFFile(destination_folder+"undeformed-lung.xdmf") as xdmf:
    xdmf.write(mesh)