# -*- coding: utf-8 -*-
"""
Created on Thu Nov 13 13:40:19 2025

@author: angus
"""
import matplotlib.pyplot as plt
import numpy as np
import meshio as io
import os
import statsmodels.stats.weightstats as sw

def IsoVolumetricSegmentation(direction, Mvec, xyz, nROI):

	V = np.sum(Mvec)
	dv = V/nROI
	d = np.ravel(xyz*direction)
	sum_mass = np.cumsum(Mvec[np.argsort(d)])
	lim_index = np.array([np.abs(sum_mass-i).argmin() for i in
						  np.linspace(dv, V, nROI)])
	id_roi = np.ones(len(Mvec))*(nROI-1)
	for i, j in enumerate(lim_index):
		if i == 0:
			id_roi[:j] = np.ones(j)*i
		else:
			id_roi[lim_index[i-1]:j] = np.ones(j-lim_index[i-1])*i

	id_roi_output = [None]*len(id_roi)
	for i, j in zip(id_roi, np.argsort(d)):
		id_roi_output[j] = int(i)

	return [sum_mass, np.sort(d)], np.array(id_roi_output)


if __name__ == '__main__':
    
    # Number of ROIS under analysis
    nrois=10
    directions = {'BA':np.mat([0.,0.,1.]).T,
                  'VD':np.mat([0.,1.,0.]).T,}
    
    # Selected direction
    direction = 'VD'
    
    # Mesh to retrieve 'mass'
    reference_mesh = 'C:/Users/angus/Downloads/CORNELL-NEWGEO/PIG5/ARDSnet/medium/experiment-mesh.vtu'
    rmesh = io.read(reference_mesh)
    mass = rmesh.point_data['Mass']
    
    # Generate ids
    _,ids = IsoVolumetricSegmentation(directions[direction], mass, rmesh.points, nrois)

    # Target folder
    folder = './problem-8/birzle-10/'
    cases = os.listdir(folder)
    
    fields = ['DeltaGasFraction','Jacobian','Phi0']
    
    data_manager = {case:{field:[] for field in fields} for case in cases}
    
    # Data manager
    
    for case in cases:    
        
        # Update path
        path = folder+case
    
        for field in ['DeltaGasFraction','Jacobian','Phi0']:
            
            mesh = io.read(path+'/%s000000.vtu'%field)
            
            if field == 'DeltaGasFraction':
                data = mesh.point_data['Delta Gas Fraction']
            elif field == 'Phi0':
                data = mesh.point_data['Phi_0']
            else:
                data = mesh.point_data[field]
            
            for roi in range(nrois):
                # Isolate mass and field
                local_mass = mass[ids==roi]
                local_data = data[ids==roi]
                # Descriptive statistics
                descr = sw.DescrStatsW(data=local_data,weights=local_mass)
                # Update data manager
                data_manager[case][field] += [descr.mean]
    
            
# %%

cases__ ={'birzle':[(grav, pleural,sf) for grav in (True,False) for pleural in (True, False) for sf in (1.0, 1.0/0.3567, 2.0/0.3567)],
            'ma':[(grav, pleural,sf) for grav in (True,False) for pleural in (True, False) for sf in (1.0, 5.0/2.0, 10.0/2.0)]}
    

data_manager[case][field]

label_namer = ["Grav | $P_{pl}$",
               "Grav | No $P_{pl}$",
               "No Grav | $P_{pl}$",
               "No Grav | No $P_{pl}$",]

ydata = np.arange(10)
xdata = np.array(data_manager[case][field])

fig,axes_ = plt.subplots(ncols=3,nrows=3,figsize=(16,12),dpi=300)


packs_ = [['case-00','case-03','case-06','case-09'],
         ['case-01','case-04','case-07','case-10'],
         ['case-02','case-05','case-08','case-11'],
         ]

bounds = {'Jacobian':(0.90,1.10),
          "DeltaGasFraction":(-0.10,0.10),
          "Phi0":(-0.0,1.0),}

colors = ['tab:blue','tab:orange','tab:green','tab:red' ]


xticks = {'Jacobian':np.linspace(0.90,1.10,5),
          'DeltaGasFraction':np.linspace(-0.10,0.10,5),
          'Phi0':np.linspace(0,1,6)}

renamer = {"Jacobian":"Jacobian (-)",
           "DeltaGasFraction":"Delta Gas Fraction (-)",
           "Phi0":"$\phi_{0}$"}

# For every row of three columns of axis
for packs,axes in zip(packs_,axes_):
    
    # For every "pack" of simulations (each with different stiffness),
    for e, (field,ax) in enumerate(zip(fields,axes)):
        
        for p, (pack,color) in enumerate(zip(packs,colors)):
            xdata = data_manager[pack][field]
            ax.plot(xdata,ydata,alpha=0.50,lw=2.5, label=label_namer[p],color=color)
            ax.scatter(xdata,ydata,color=color)

        ax.set_xlim(bounds[field])
        ax.set_xlabel(renamer[field],size=14)
        
        if e == 0:
            ax.axvline(0.0, color = "k", ls = "--", alpha=0.75)
            ax.set_ylabel('ROI ID',size=14)
            ax.set_yticks(np.arange(10))
            ax.set_yticklabels(np.arange(10)+1,size=12)
            x0,x1 = ax.get_xlim(); dx = x1-x0
            ax.text(x0-0.30*dx, -0.6, "Ventral",size=14)
            ax.text(x0-0.30*dx, 10, "Dorsal",size=14)
    
        elif e == 1:
            ax.axvline(1.0, color = "k", ls = "--", alpha=0.75)
            ax.set_yticks([])
    
        else:
            ax.axvline(0.0, color = "k", ls = "--", alpha=0.75)
            ax.axvline(1.0, color = "k", ls = "--", alpha=0.75)
            ax.set_yticks([])
            ax.legend()
        
        ax.set_xticks(xticks[field])
        
        if e != 2:
            ax.set_xticklabels(["%.2f"%x for x in xticks[field]], size=12)
        else:
            ax.set_xticklabels(["%.1f"%x for x in xticks[field]], size=12)

        ax.invert_yaxis()
        
plt.tight_layout()