# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 14:30:27 2025

@author: angus
"""


import argparse

from dolfin import *
import numpy as np
import dolfin, os, shutil
import sys
sys.path.append("/mnt/c/Users/angus/OneDrive - Universidad Católica de Chile/Documentos/GitHub/ards-lung-simulator/src/")
import AirwayManager as awm
import modelfunctions as md
import supportfunctions as sf
from scipy.optimize import curve_fit

'''
Attempts to include the PEEP as an explicit term, now considering pleural pressure and gravity effects
simultaneously. Note that we may divide this into a separate step, first removing PEEP and then removing 
pleural pressure and gravity effects, but the space the second F tensor inhabits may become weird, as the
deformed (current) mesh configurations are different.

Incorpores variable tissue stiffness.
'''

def parse_args():
    parser = argparse.ArgumentParser(
        description="Example script with restricted command-line options."
    )

    # Float parameter with no restrictions other than type
    parser.add_argument(
        "-ctissue",
        type=float,
        default=1.6717,
        help="Tissue coefficient (float). Default: 0.3567"
    )

    # Another float parameter
    parser.add_argument(
        "-kcw",
        type=float,
        default=0.0407,
        help="Chest wall K coefficient (float). Default: 0.0407"
    )

    # Another float parameter
    parser.add_argument(
        "-kd",
        type=float,
        default=0.0487,
        help="Diaphragm K coefficient (float). Default: 0.0487"
    )
    
    # Another float parameter
    parser.add_argument(
        "-p_alv",
        type=float,
        default=10.7876,
        help="Alveolar pressure in (cmH2O) (float). Default: 10 cmH2O"
    )
    
    # Another float parameter
    parser.add_argument(
        "-dp",
        type=float,
        default=10.0,
        help="Pressure gradient in cmH2O (float). Default: 10.0"
    )

    # Another float parameter
    parser.add_argument(
        "-gamma_insp",
        type=float,
        default=0.2944,
        help="Inspiratory gamma value (float). Default: 0.2944"
    )
    
    # Another float parameter
    parser.add_argument(
        "-kappa",
        type=float,
        default=1e5,
        help="Permeability (float). Default: 1e5"
    )

    # Restricted values parameter
    parser.add_argument(
        "-gravity",
        type=int,
        choices=[0, 1],
        default=1,
        help="Gravity direction: 1 (on), 0 (off). Default: 1"
    )

    return parser.parse_args()


def determineAveragePressures(p,u,dx,Nsd,verbose=False,Fprev=None):
    
    '''
    Function to determine the average pressure in every reference subdomain.
    '''
    
    # Create a data structure to hold the pressure values
    subdomain_averaged_pressure = np.empty(Nsd)

    J = md.JJ(u,p,Fprev=Fprev)

    # Determine the average pressure in every subdomain
    for j in range(Nsd):
        # Arrange the operator being omputed
        
        pressure_kernel=p*J*dx(j)
        volume_kernel= J *dx(j)
        avg_pressure = dolfin.assemble(pressure_kernel)
        subdomain_deformed_volume = dolfin.assemble(volume_kernel)
        
        # Assign average value to the data structure
        subdomain_averaged_pressure[j] = avg_pressure/subdomain_deformed_volume
        
    return subdomain_averaged_pressure

def determineTreeInletConditions(t, Q, Tinsp, duration_step, presfn=None, 
                                 flowfn=None, t_tol=1e-4, pplat=None,peep=0.0,
                                 block="NULL"):
    '''
    Set the values for Q0 and P0, flow and pressure at the inlet of the airway
    tree according to the current time in the simulation.
    
    '''
    # Set the inlet variables for the airway tree
    if t<=Tinsp: # 1st Inspiration + Inspiratory pause 
        if flowfn is None:
            Q0 = Q; P0 = None
        else:
            Q0 = flowfn(t); P0=None
        
        block="A"
    elif Tinsp<t<=duration_step: # 1st Expiration
        if presfn is None:    
            Q0 = None; P0 = peep
        else:
            Q0 = None;
            try:
                P0 = min([presfn(t,pplat),pplat])
            except:
                P0 = presfn(t,pplat)
                print("Failed to determine a mininum pressure")
        block="B"
                
    elif duration_step<t<duration_step+Tinsp: # 2nd Inspiration
        if flowfn is None:
            Q0 = Q; P0 = None
        else:
            Q0 = flowfn(t); P0 = None
        block="C"
            
    else: # 2nd Expiration
        if presfn is None:    
            Q0 = None; P0 = peep
        else:
            Q0 = None
            try:
                P0 = min([presfn(t,pplat),pplat])
            except:
                P0 = presfn(t,pplat)
                print("Failed to determine a mininum pressure")
        block="D"

    if (Q0 is None) and (P0 is None):
        print("Warning: Both Q0 and P0 are None and this will cause a crash")
        print("Block where the condition was prescribed: Block '%s'"%block)        
                
    return Q0, P0

def create_flow_function(time_arr, flow, t_cycle = 2.00,t_end_inspiration = 0.375, 
                  t_insp_transition = 0.470, t_end_insp_pause = 0.750, 
                  t_exp_start = 0.810):

    # Inspiration Exponential functoin
    mask = np.array(time_arr<t_end_inspiration)
    def func1(x, a, b): return -a *(1 - np.exp(-b * x))
    popt1, pcov = curve_fit(func1, time_arr[mask], flow[mask])
    # Linear decay
    mask = np.logical_and(time_arr>t_end_inspiration,time_arr<t_insp_transition)
    def func2(x, a, b): return (a * x + b)
    popt2, pcov = curve_fit(func2, time_arr[mask], flow[mask])
    # Inspiratory pause, zero flux
    def func3(x): return 0.0
    # Expiration linear function
    mask = np.logical_and(time_arr>t_end_insp_pause,time_arr<t_exp_start)
    def func4(x, a, b): return (a * x + b)
    popt4, pcov = curve_fit(func4, time_arr[mask], flow[mask])
    # Expiration linear function
    mask = np.logical_and(time_arr>t_exp_start,time_arr<t_cycle)
    def func5(x, a, b): return (a * x + b)
    popt5, pcov = curve_fit(func5, time_arr[mask], flow[mask])

    # Definition of the flow function
    def flow_func(x, tcycle=2.0):
        
        if x>tcycle:
            x = x%t_cycle
        
        if x<t_end_inspiration:
            return func1(x,*popt1)
        elif x>=t_end_inspiration and x<t_insp_transition:
            return func2(x,*popt2)
        elif x>=t_insp_transition and x<t_end_insp_pause:
            return func3(x)
        elif x>=t_end_insp_pause and x<t_exp_start:
            return func4(x,*popt4)
        elif x>=t_exp_start and x<=t_cycle:
            return func5(x,*popt5)
        else:
            return 0.0
        
    return flow_func

def stress_bir2019_inv(u,p,p_alv,c=0.3567,beta=1.075):
    
    I = Identity(3)
    F = inv(I + grad(u))
    C=variable(F.T*F)
    I1C=variable(tr(C))
    I2C=0.5*((tr(C)**2)-tr(C*C))
    I3C=variable(det(C))
    J=variable(sqrt(I3C))
    I1raya=I1C*pow(I3C,-1/3)
    psi=c*(I1C-3)  +  (c/beta)*(pow(I3C,-beta)-1)+(278.2/1000)*pow((pow(I3C,-1/3)*I1C-3),3)+(5.766/1000)*pow((pow(I3C,1/3)-1),6)
    S=2*diff(psi,C)
    sigma = 1./J*F*S*F.T - (p+p_alv)*I # Akin to what we had for P
    
    return sigma ,F, J

def stress_ma_inv(u, p,p_alv, c=2.0, a = 0.43, b=-0.6):
    
    I = Identity(3)
    F = inv(I + grad(u))
    J = det(F)
    C=variable(F.T*F)
    E=0.5*(C-I)
    I1E=tr(E)
    I2E=0.5*((tr(E)**2)-tr(E*E))
    I3E=det(E)
    aa=Constant(a)
    bb=Constant(b)
    psi=c*exp(aa*I1E*I1E+bb*I2E)
    S=2*diff(psi,C)
    sigma = 1./J*F*S*F.T - (p+p_alv)*I # Akin to what we had for P
    
    return sigma, F, J 
      
def stress_bir2019(u, p,p_alv,c=0.3567,beta=1.075,Fprev=None):
    I = Identity(3)
    F = (I + grad(u))
    
    if not Fprev is None:        
        F = F*Fprev
        
    C=variable(F.T*F)
    I1C=variable(tr(C))
    I2C=0.5*((tr(C)**2)-tr(C*C))
    I3C=variable(det(C))
    J=variable(sqrt(I3C))
    I1raya=I1C*pow(I3C,-1/3)
    psi=c*(I1C-3)  +  (c/beta)*(pow(I3C,-beta)-1)+(278.2/1000)*pow((pow(I3C,-1/3)*I1C-3),3)+(5.766/1000)*pow((pow(I3C,1/3)-1),6)
    S=2*diff(psi,C)
    PK=F*S-p*J*inv(F).T 
    return PK          


 
def stress_ma(u, p,p_alv, c=2.0, a = 0.43, b=-0.6, Fprev = None):
    I = Identity(3)
    F = I + grad(u)
    
    if not Fprev is None:
        F = F*Fprev        
    J = det(F)
    C=variable(F.T*F)
    E=0.5*(C-I)
    I1E=tr(E)
    I2E=0.5*((tr(E)**2)-tr(E*E))
    I3E=det(E)
    aa=Constant(a)
    bb=Constant(b)
    psi=c*exp(aa*I1E*I1E+bb*I2E)
    S=2*diff(psi,C)
    PK=F*S-(p+p_alv)*J*inv(F).T 
    return PK          


def ida_complete_unload(mesh_info, material_parameters, output_to, 
                     activate_gravity = True,
                     activate_pleural_pressure = True, dp=5.0):
    
    # Unpack material parameters
    phi = material_parameters['ee-phi']
    kappa = material_parameters['permeability']
    c_tissue = material_parameters['c_tissue']
    rho_a = material_parameters['rho_a']
    rho_t = material_parameters['rho_t']
    g = material_parameters['gravity_vector']
    p_alv = material_parameters['p_alv']
 
    # Unpack meshes
    mesh = mesh_info['mesh']
    boundary_markers = mesh_info['boundary_markers']
    
    inv_output_to = output_to + "inverse-analysis/"
    
    if os.path.isdir(inv_output_to):
        shutil.rmtree(inv_output_to)
    os.mkdir(inv_output_to)
    
    # =============================================================================
    # Physical parameters
    # =============================================================================
    
    # Densities and gravity
    rho_t = Constant(rho_t)  # (tissue) Water density  kg/mm3
    rho_a = Constant(rho_a) # (air) Air density kg/mm3 
    
    # ---------------------- function spaces ----------------------
    P2 = VectorElement("Lagrange", mesh.ufl_cell(), 2)
    P1 = FiniteElement("CG", mesh.ufl_cell(), 1)
    TH = P2*P1 # Taylor-Hood
    W = FunctionSpace(mesh, TH)
    
    # Functions for displacement and pressure
    w = dolfin.Function(W)
    u, p = dolfin.split(w)
    
    # Test and trial functions
    _u, _p = dolfin.TestFunctions(W)
    du = dolfin.TrialFunction(W) 
    
    # Define a placeholder for a (potentially) spatially variable phi0 
    G = FunctionSpace(mesh,"CG",1)
            
    # Define geometric measures and limit quadrature degree
    dx = dolfin.Measure("dx", domain=mesh)
    ds = Measure('ds', domain=mesh, subdomain_data=boundary_markers)
    dx = dx(degree=3)
    ds = ds(degree=3)
        
    dolfin.info("Num DOFs {}".format(W.dim()))
    
    # ---------------------- kinematics & constitutive ----------------------
    
    # Determine the first Piola Kirchoff tensor
    if constitutive_model == 'birzle':
        sigma,F,J = stress_bir2019_inv(u,p,p_alv,c=c_tissue)
    elif constitutive_model == 'ma':
        sigma,F,J = stress_ma_inv(u,p,p_alv,c=c_tissue)
    else:
        raise Exception("Wrong constitutive model selection")
    

    # Flux
    if activate_gravity:
        q = -kappa*(grad((p+p_alv))+rho_a*g)
    else:
        q = -kappa*grad((p+p_alv))
        
    if activate_pleural_pressure:
        # Retrieve geometry bounds
        _, y_min, _ = mesh.coordinates().min(axis=0) 
        _, y_max, _ = mesh.coordinates().max(axis=0) # 
        
        # Define the pressures being applied
        p_max = 0 # transform cmH2O into kPa
        p_min = dp / 10.1972 # Forced to be zero
        
        # Note that the lung is 'upside down' and the ventral region occurs
        # at y_min and and the dorsal at y_max.
        p_expr = Expression(
            "p_min + (p_max - p_min)*(y_max-x[1])/(y_max - y_min)",
            degree=1,
            p_max=p_max,
            p_min=p_min,
            y_min=y_min,
            y_max=y_max
        ) 
        
        Qp = FunctionSpace(mesh,"CG",1)
        p_test = interpolate(p_expr, Qp)
        
        with XDMFFile(mesh.mpi_comm(), inv_output_to+"pressure-field.xdmf") as xdmf:
            xdmf.write(p_test, 0.0)
        
        # Define a normal function
        n = FacetNormal(mesh)

    K_inf=1e12

    F0 = dolfin.inner(u,_u)*K_inf*dolfin.ds(subdomain_data=boundary_markers,
                                          subdomain_id=3) # Dorsal support  
    
    
    
    # Residual: mechanical + body force + incompressibility (pressure) equation
    Res = inner(sigma, grad(_u))*dx - inner(q, grad(_p))*dx + F0 #+ F2 #+  F1
    
    if activate_gravity:
        # Composite density term in deformed configuration
        R = (J-phi)*rho_t + phi*rho_a
        
        Res -=  R*dot(g, _u)*dx 
    
    if activate_pleural_pressure:
        F3 = dolfin.inner(p_test*n,_u)* dolfin.ds(subdomain_data=boundary_markers,
                                              subdomain_id=2) # Chest wall
        
        Res -= F3
        
    # Jacobian (derivative of residual w.r.t the mixed unknown w in direction du)
    Jac = derivative(Res, w, du)
    
    # Build the problem
    problem = NonlinearVariationalProblem(Res, w, J=Jac)
    solver = NonlinearVariationalSolver(problem)
    
    # First solver parameter definition
    solver_parameters = {"nonlinear_solver":"snes",
                         "snes_solver":{"linear_solver":"mumps",
                                        "relative_tolerance":1e-6,
                                        "absolute_tolerance":1e-8,
                                        "maximum_iterations":60,
                                        "line_search":"bt",
                                        "report":True,
                                        "error_on_nonconvergence":True,
                                        "preconditioner":"none"}
                         }
    
    # First solver parameter definition
    solver.parameters.update(solver_parameters)
    # Solve 
    solver.solve()
    
    # Define output spaces
    T = dolfin.TensorFunctionSpace(mesh, "CG", 1) 
    Q = dolfin.FunctionSpace(mesh, 'CG', 1)
    V = dolfin.VectorFunctionSpace(mesh, "Lagrange", 1)  ##
    
    # Extract solution components
    u, p = w.split()
    u.rename("Displacement", "")
    p.rename("Pressure", "")
    
    # Kinematics
    I = Identity(len(u))
    F = inv(I + grad(u))
    C = F.T*F
    J = det(F)
    
    # Compute the variables again (why?)
    if constitutive_model == 'birzle':
        sigma,F,J = stress_bir2019_inv(u,p,p_alv,c=c_tissue)
    elif constitutive_model == 'ma':
        sigma,F,J = stress_ma_inv(u,p,p_alv,c=c_tissue)
    else:
        raise Exception("Wrong constitutive model selection")
        
    # Convert to Cauchy stress for von Mises
    #sigma = (1.0/J) * P * F.T
    
    # Determine hydrostatic pressure
    P_hyd = -1./3.*tr(sigma)*10.1972 # in cmH2O
    P_hyd_ = project(P_hyd, Q)
    P_hyd_.rename("Hydrostatic pressure (cmH2O)","")
        
    # Deformation gradient
    F_out = project(F, T)
    F_out.rename("F","")
    
    # Original (?) porosity
    phi0 = phi + 1 - J
    phi0_out = project(phi0, Q)
    phi0_out.rename("Phi_0","")
    
    # Eulerian porosity
    phi_out = project(phi, Q)
    phi_out.rename("Phi","")
    
    # Delta Gas fraction
    dgf = phi - phi0 # Tiene sentido? Quizás no
    dgf_out = project(dgf, Q)
    dgf_out.rename("Delta Gas Fraction","")
    
    # Jacobian
    Jproj = project(J, Q)
    Jproj.rename("Jacobian", "")


    t = 0.0 # Dummy
    # Create one .pvd file per variable
    F_file = File(inv_output_to + "F.pvd")
    P_hyd_file = File(inv_output_to + "HydrostaticPressure.pvd")
    u_file = File(inv_output_to + "Displacement.pvd")
    p_file = File(inv_output_to + "Pressure.pvd")
    phi0_file = File(inv_output_to + "Phi0.pvd")
    phi_file = File(inv_output_to + "Phi.pvd")
    J_file = File(inv_output_to + "Jacobian.pvd")
    dgf_file = File(inv_output_to + "DeltaGasFraction.pvd")
    
    # Write each variable to its file
    F_file << (F_out, t)
    P_hyd_file << (P_hyd_, t)
    u_file << (u, t)
    p_file << (p, t)
    phi0_file << (phi0_out, t)
    phi_file << (phi_out, t)
    J_file << (Jproj, t)
    dgf_file << (dgf_out, t)
        
    return F, det(F)

def initialize_mesh(root_mesh):
    
    mesh = dolfin.Mesh()
    
    # Load tetraedral mesh
    hdf = dolfin.HDF5File(mesh.mpi_comm(), root_mesh+'tetrahedral_mesh.h5', "r")
    hdf.read(mesh, "/mesh", False)
    # Load markers
    boundary_markers = dolfin.MeshFunction("size_t", mesh, mesh.topology().dim() - 1)
    hdf.read(boundary_markers, "/boundary_markers")
    hdf.close()
    
    subdomains = MeshFunction("size_t", mesh, root_mesh+"/Omega.xml.gz")
    
    mesh_info = {'mesh':mesh,
                 'boundary_markers':boundary_markers,
                 'subdomains':subdomains}
    
    return mesh_info

 
def forward_poroelastic_step(ts, flowfn, Fprev, mesh_info, material_parameters,
                             gravity_activate=True, max_nit=30):
    
    cm = material_parameters['constitutive_model']
    c_tissue = material_parameters['c_tissue']
    phi0 = material_parameters['ee-phi']
    KK = material_parameters['permeability']
    pedley_gamma_insp = material_parameters['gamma_insp']
    K_cw_stiffness = material_parameters['K_cw']
    K_d_stiffness = material_parameters['K_d']
    rho_a = material_parameters['rho_a']
    rho_t = material_parameters['rho_t']
    gvec = material_parameters['gravity_vector']
    p_alv = material_parameters['p_alv']

    K_inf = 1e12
    
    # Mesh info
    mesh = mesh_info['mesh']
    boundary_markers = mesh_info['boundary_markers']
    subdomains = mesh_info['subdomains']
    
    # Get mesh dimension and prepare boundary measure
    gdim = mesh.geometry().dim()
    dx = dolfin.Measure("dx", domain=mesh, subdomain_data=subdomains)
    ds = dolfin.Measure("ds", domain=mesh, subdomain_data=boundary_markers)
    
    # Limit quadrature degree
    dx = dx(degree=3)
    ds = ds(degree=3)
    
    # Build function space. We use Taylor-Hood element
    V = dolfin.VectorFunctionSpace(mesh, "Lagrange", 1)  ##
    P2 = dolfin.VectorElement("Lagrange", mesh.ufl_cell(), 2)
    P1 = dolfin.FiniteElement("CG", mesh.ufl_cell(), 1)
    TH = P2 * P1  #Taylor 
    W = dolfin.FunctionSpace(mesh, TH)  #creo el nuevo espacio de funciones (mixto) DESPLAZAMIENTO Y PRESION
    dolfin.info("Num DOFs {}".format(W.dim()))
     
    #Define an expression to time step
    dt = dolfin.Expression(("beta"), beta=0., degree=2, domain=mesh)
    
    # Load the airway tree and retrieve number of subdomains
    path_to_airway = "/mnt/c/Users/angus/Downloads/CORNELL-NEWGEO/PIG5/ARDSnet/medium/skel.vtu"
  
    tree = awm.Pipeline(path_to_airway, gamma=pedley_gamma_insp)
    Nsd = np.count_nonzero(tree.distal_elem_ids)
    tree.update_gamma(pedley_gamma_insp)
    
    # Initialize sources with zero values
    sources = {i:0.0 for i in np.arange(Nsd)}   
    # Build object
    src = sf.build_source_term(subdomains, sources)

    # Unknowns, values at previous step and test functions
    w = dolfin.Function(W)
    u, p = dolfin.split(w)
    
    w0 = dolfin.Function(W)
    u0, p0 = dolfin.split(w0)
    
    _u, _p = dolfin.TestFunctions(W)
    du = dolfin.TrialFunction(W)    

    I = dolfin.Identity(W.mesh().geometry().dim())
        
    if cm=='ma':
        P=stress_ma(u,p,p_alv,c=c_tissue,Fprev=Fprev)
    elif cm=='birzle':
        P=stress_bir2019(u,p,p_alv,c=c_tissue,Fprev=Fprev)   
        
    # Eqn (37)'s first term; Gravity term omitted.
    # P: First Piola Kirchoff stress tensor
    # _u: Trial function for displacement field
    # dx: Volume measure
    F1_base=dolfin.inner(P, dolfin.grad(_u) )*dolfin.dx 
    
    if gravity_activate:
        
        F1_grav = dolfin.inner((md.JJ(u,p,Fprev=Fprev)*rho_a + (1 - phi0)*(rho_t-rho_a))*gvec,_u)*dolfin.dx
        F1 = F1_base-F1_grav
        
    else:
        F1 = F1_base
        
    # *** Where does this term stem from? *** dPhi/dt
    # Jacobian(u) * Trace(grad(u)-grad(u0))*Finv(u)
    # JJ computes jacobian from displacement field u, p is not used.
    # u0: Obtained from a split applied to w0, a function from the W mixed 
    #     function space.
    # Finv: The inverse from the deformation gradient tensor computed from
    #       'u', p is not used.
    F2aux1=md.JJ(u,p,Fprev=Fprev)*tr((grad(u)-grad(u0))*md.Finv(u,p,Fprev=Fprev)) 
        
    # KK: Permeability as a constant
    # This computes a term similar to 'Q' as defined in eqn. (21), while
    # disregarding gravity effects
    F2aux2=md.F2aux_mass(u,p,KK,gravity_activate=gravity_activate,rho_a=rho_a,gvec=gvec,Fprev=Fprev)
    
    F2aux3 = src*(md.JJ(u,p,Fprev=Fprev)-1+phi0)# ORIGINAL

    F2= (dolfin.inner(F2aux1, _p))*dolfin.dx + \
        dt*(dolfin.inner(grad(_p),F2aux2))*dolfin.dx + \
        dt*dolfin.inner(_p,F2aux3)*dolfin.dx    
    
    # Compute spring force acting upon the lung's surface
    F3=dolfin.inner(u,_u)*K_cw_stiffness*dolfin.ds(subdomain_data=boundary_markers,
                                             subdomain_id=2) # Chest wall
    
    # Make the diaphragm much less stiffer than the thoracic cage
    F4=dolfin.inner(u,_u)*K_d_stiffness*dolfin.ds(subdomain_data=boundary_markers,
                                             subdomain_id=1) # Diaphragm

    if gravity_activate:
        # Activate the gravitational effects
        F5=dolfin.inner(u,_u)*K_inf*dolfin.ds(subdomain_data=boundary_markers,
                                              subdomain_id=3) # Dorsal  
    else:            
        # Instead of a stiff dorsal region, use the conventional 
        F5=dolfin.inner(u,_u)*K_cw_stiffness*dolfin.ds(subdomain_data=boundary_markers,
                                              subdomain_id=3) # Dorsal  
    
    R=F1+F2+F3+F4+F5

    # Derivative to the functional
    Jac = dolfin.derivative(R, w, du)
    
    # Initialize solver
    problem = dolfin.NonlinearVariationalProblem(R, w, J=Jac,
                                          form_compiler_parameters={'optimize':True})
    
    solver = dolfin.NonlinearVariationalSolver(problem)
    
    # First solver parameter definition
    solver_dict = {"nonlinear_solver":"snes",
               "snes_solver":{"linear_solver":"mumps",
                              "relative_tolerance":1e-6,
                              "absolute_tolerance":1e-8,
                              "maximum_iterations":60,
                              "line_search":"bt",
                              "report":True,
                              "error_on_nonconvergence":True,
                              "preconditioner":"default"}
                              }
    solver.parameters.update(solver_dict)
    solver.solve()

    # Extract solution components
    u, p = w.split()
    u.rename("u", "displacement")
    p.rename("p", "pressure")


    Jacob=[]
    fluxes=[]
    presionestodas=[]
    effectivetimes=[]
    prescribedfluxes=[]
        
    for i in np.arange(len(ts)):
        
        # Read prescribed fluxes and current simulation time
        t=ts[i]
        dt = ts[1]-ts[0]
        
        if i==0: 
            # Initialize the arrays
            
            # Determine average pressures from initial conditions (0)
            current_it_subdomain_pressure = determineAveragePressures(p,u,dx,Nsd,Fprev=Fprev)
                        
            # Change format for compatibility with the tree system
            Pdistal = {tree.translate["s2p"][s]:current_it_subdomain_pressure[s] for s in range(Nsd)}
                        
            # Assemble linear system using the average pressures
            tree.assemble_linear_system(Pdistal=Pdistal, Q0=flowfn(t))
            # Initialize the subdomain deformed volume array using the reference volumes
            current_it_subdomain_defomed_volume = np.empty(Nsd,dtype=float)
            J = md.JJ(u,p,Fprev=Fprev)
            
            for j in range(Nsd):
                dummy = (J-1+phi0)*dx(j)
                current_it_subdomain_defomed_volume[j] = dolfin.assemble(dummy)
                            
        
        print("Time: %.3f [s]"%t)

        # Iterative loop for convergence in airway tree and lung information
        for ii in range(max_nit):
            
            if ii == 0 and True:
                
                print("\n"*4)
                print("***********************************")
                print("***** Starting iterative loop *****")
                print("***********************************")
                            
            # Backup the previously converged subdomain averaged pressure and deformed volume to be used later when 
            # computing a norm assocciated to the convergence between iterative cycles of this value.
            prev_it_subdomain_pressure = current_it_subdomain_pressure.copy()
            prev_it_subdomain_defomed_volume = current_it_subdomain_defomed_volume.copy()

            # Set the inlet variables for the airway tree
            Q0, P0 = determineTreeInletConditions(t, flowfn(t), 0.750, 2.0,
                                                  presfn=None, flowfn=flowfn, 
                                                  pplat=None, peep=None)
            
            # Update the linear system with the Pdistal which is defined at the end of an iterative loop with the 
            # previous step subdomain-averaged values.
            tree.update_linear_system(Pdistal, Q0=Q0, P0=P0)
            
            # Solve the linear system associated to the flow in the airway tree
            tree.solve_linear_system()
            
            if True:
                ped_cnt = 0 # Initialize counter
                x_old = tree.x.copy()
                err = 999 # Initialize error in a high value
                while err > 1e-5:
                    # Update the Pedley resistances
                    tree.update_pedley_resistances()
                    # Solve the linear system
                    tree.solve_linear_system()
                    # Determine a the error
                    err = np.linalg.norm(x_old-tree.x)/np.linalg.norm(tree.x)
                    # Update counter and save current error as x_old
                    ped_cnt += 1 
                    x_old = tree.x.copy()
                    #print("err: ",err)
                    if ped_cnt>30:
                        print("Divergence at Pedley's iterations")
                        return False
                    
            # Retrieve the new fluxes that are going to become input for the poromechanical system
            subdomain_fluxes = tree.retrieve_qs()
            
            # Update the source values according to subdomain air volume and the recently computed fluxes.
            sources = {j:subdomain_fluxes[j]/prev_it_subdomain_defomed_volume[j] for j in range(Nsd)}
            src.update(sources)
            
            # Solve the poromechanical model
            solver.solve()
             
            # Determine the new subdomain averaged pressures and store them
            # in current_subd_pressure.
            current_it_subdomain_pressure = determineAveragePressures(p,u,dx,Nsd)

            # Determine the current deformed volume of the lung
            current_it_subdomain_defomed_volume = np.empty(Nsd,dtype=float)
            J = md.JJ(u,p,Fprev=Fprev)
            for j in range(Nsd):
                dummy = (J+phi0)*dx(j)
                current_it_subdomain_defomed_volume[j] = dolfin.assemble(dummy)
                            
            # Compute a norm for the difference between the previous iteration 
            # and the current subdomain pressures.
            p_diff = np.linalg.norm(prev_it_subdomain_pressure - current_it_subdomain_pressure)
            
            # Determine the difference between the difference between iterations
            v_diff = np.linalg.norm(current_it_subdomain_defomed_volume - prev_it_subdomain_defomed_volume)

            # Change format for compatibility with the tree system (to be used in the next iteration). 
            Pdistal = {tree.translate["s2p"][s]:current_it_subdomain_pressure[s] for s in range(Nsd)}            
            
            # Report the difference
            print("Pressure difference: ",p_diff)
            print("Volume difference: ", v_diff)
            
            print("\n*************** ITERATIVE STEP %i OVER ***************\n"%ii)
            
            
            convergence_criteria = p_diff < 1e-8
            
            # If the difference is below the tolerance, save the results and
            # move into the new step
            if convergence_criteria:
                
                # Compute mean Jacobian    
                vol_=dolfin.assemble((det(I+grad(u)))*dx)
                volL=vol_/(10**6)
                deltavol=dolfin.assemble(((md.JJ(u,p,Fprev=Fprev)-md.JJ(u0,p0,Fprev=Fprev))/dt)*dx)
                
                # Append the new quantities
                presionestodas.append(tree.x[tree.N])
                Jacob.append(volL)

                # If we are in the starting time, keep this pressure value as a PEEP approximation
                if i == 0: 
                    peep = presionestodas[0]
                  #  print("PEEP: %.2f"%(peep*10.1972))
                prescribedfluxes.append(flowfn(t))
                    
                fluxes.append(deltavol*1e-6)
                effectivetimes.append(t)    

                # Assign the converged current result to the 'previous' step 
                # variable so that the next round of computations is OK.
                w0.assign(w)

                break
            
            elif not convergence_criteria and ii == (max_nit-1):
                
                print("Reached maximum number of iterations without convergence.")
                return False
    
    return peep*10.1972
        


if __name__ == '__main__':
    
    args = parse_args()

    print("Running simulation with:")
    print(f"  ctissue = {args.ctissue}")
    print(f"  dp = {args.dp}")
    print(f"  gamma_insp     = {args.gamma_insp}")
    print(f"  kd     = {args.kd}")
    print(f"  kcw     = {args.kcw}")
    print(f"  gravity = {args.gravity}")
    print(f"  kappa     = {args.kappa}")
    print(f"  p_alv     = {args.p_alv}")

    
    destination_folder = "./problem-16/"
    if not os.path.isdir(destination_folder):
        os.mkdir(destination_folder)
    
    root_mesh = "/mnt/c/Users/angus/Downloads/CORNELL-NEWGEO/PIG5/ARDSnet/medium/FEniCS/"
    
    # Output folder
    output_to = destination_folder
    constitutive_model = 'birzle'
    c_tissue = args.ctissue
    dp = args.dp
    pedley_gamma_insp = args.gamma_insp
    dt = 1e-7
    ts = [i*dt for i in [1,2]]
    rho_t = 1e-6
    rho_a = 1e-9
    g_magnitude = 9810.
    g = Constant((0.0, g_magnitude, 0.0))  # Gravity vector in mm/s2 (downwards)
    K_d = args.kd
    K_cw = args.kcw
    kappa = args.kappa
    p_alv = args.p_alv / 10.1972 # cmH2O to kPa
    
    print("Using '%s' constitutive model"%constitutive_model)

    
    # Path to experimental data, load matlab file and prepare data
    signal_path = '/mnt/c/Users/angus/Downloads/CORNELL-NEWGEO/PIG5/PIG5-ARDSnet.npz'

    # Load the experimental signal
    npz = np.load(signal_path)
    aw_pressure = npz['pressure']/10.1972 # kPa
    flow = npz['flow']*(1e6)
    time = npz['time']

    # Define flow and pressure functions
    flowfn = create_flow_function(time, flow,
                                   t_cycle = 2.00,t_end_inspiration = 0.375, 
                                   t_insp_transition = 0.470, t_end_insp_pause = 0.750, 
                                   t_exp_start = 0.810)
        
    # Initialize mesh
    mesh_info = initialize_mesh(root_mesh)

    # Useful dictionaries to define parameters
    porosity_config = {'read_from_file':True,
                       'path_to_file':root_mesh+"phi0.xml.gz",
                       'property_name':'End-expiratory porosity'}
    
    permeability_config = {'read_from_file':False,
                           'path_to_file':'',
                           'property_name':'Permeability',
                           'property_value':kappa,
                           }
    
    stiffness_config = {'read_from_file':True,
                        'path_to_file':root_mesh+'c_tissue.xml.gz',
                        'property_name':'Tissue stiffness',
                        'property_value':c_tissue,
                           }
    
    # Define the spatially-variable parameters
    c_tissue = sf.define_property(mesh_info['mesh'], stiffness_config)
    KK = sf.define_property(mesh_info['mesh'] ,permeability_config)
    phi = sf.define_property(mesh_info['mesh'] ,porosity_config)    
    
    # Include the relevant parameters
    material_parameters = {'constitutive_model':constitutive_model,
                           'c_tissue':c_tissue,
                           'ee-phi':phi,
                           'permeability':KK,  
                           'rho_a':rho_a,
                           'rho_t':rho_t,
                           'gravity_vector':g,
                           'gamma_insp':pedley_gamma_insp,
                           'K_cw':K_cw,
                           'K_d':K_d,
                           'p_alv':p_alv,
                           }

    #Define some dolfin parameters
    dolfin.parameters["form_compiler"]["cpp_optimize"] = True
    dolfin.parameters["form_compiler"]["representation"] = "uflacs"
    dolfin.parameters["form_compiler"]["quadrature_degree"] = 4
    dolfin.parameters["allow_extrapolation"] = True 
    dolfin.parameters["form_compiler"]["optimize"] = True 
    
    output_to = destination_folder
    
    Fpeep, Jpeep = ida_complete_unload(mesh_info, material_parameters,output_to,
                                    activate_gravity = True,
                                    activate_pleural_pressure = True, 
                                    dp=dp, )

    
    try:
        peep = forward_poroelastic_step(ts, flowfn, Fpeep, mesh_info, material_parameters,
                             gravity_activate=True, max_nit=30)
    
        print("PEEP value: %.2f (cmH2O)"%peep)
     #   return peep
    except:
        print("Forward analysis failed")
        pass
   #     return 