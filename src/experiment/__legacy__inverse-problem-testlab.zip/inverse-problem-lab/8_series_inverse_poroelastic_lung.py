# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 14:30:27 2025

@author: angus
"""

from dolfin import *
import numpy as np
import dolfin, os

def stress_bir2019(u, p,c=0.3567,beta=1.075):
    I = Identity(3)
    F = inv(I + grad(u))
    C=variable(F.T*F)
    I1C=variable(tr(C))
    I2C=0.5*((tr(C)**2)-tr(C*C))
    I3C=variable(det(C))
    J=variable(sqrt(I3C))
    I1raya=I1C*pow(I3C,-1/3)
    psi=c*(I1C-3)  +  (c/beta)*(pow(I3C,-beta)-1)+(278.2/1000)*pow((pow(I3C,-1/3)*I1C-3),3)+(5.766/1000)*pow((pow(I3C,1/3)-1),6)
    S=2*diff(psi,C)
    sigma = 1./J*F*S*F.T - p*I # Akin to what we had for P
    return sigma ,F, J
    
def stress_ma_inv(u, p, c=2.0, a = 0.43, b=-0.6):
    I = Identity(3)
    F = inv(I + grad(u))
    J = det(F)
    C=variable(F.T*F)
    E=0.5*(C-I)
    I1E=tr(E)
    I2E=0.5*((tr(E)**2)-tr(E*E))
    I3E=det(E)
    aa=Constant(a)
    bb=Constant(b)
    psi=c*exp(aa*I1E*I1E+bb*I2E)
    S=2*diff(psi,C)
    sigma = 1./J*F*S*F.T - p*I # Akin to what we had for P
    return sigma, F, J       

def inverse_simulation(constitutive_model, output_to, 
                       scaling_factor=1.0, 
                       activate_gravity=False, 
                       activate_pleural_pressure=True,
                       dp=5.0):

    #Define some dolfin parameters
    dolfin.parameters["form_compiler"]["cpp_optimize"] = True
    dolfin.parameters["form_compiler"]["representation"] = "uflacs"
    dolfin.parameters["form_compiler"]["quadrature_degree"] = 4
    dolfin.parameters["allow_extrapolation"] = True 
    dolfin.parameters["form_compiler"]["optimize"] = True 
    
    if os.path.isdir(output_to):
        os.remove(output_to)
    os.mkdir(output_to)
    
    
    # =============================================================================
    # Physical parameters
    # =============================================================================

    # Permeability
    kappa = 1e5 # Permeability, as defined in AR&H (2022)
    K_inf = 1e12
    
    # Densities and gravity
    rho_t = Constant(1.0e-6)  # (tissue) Water density  kg/mm3
    rho_a = Constant(1.0e-9) # (air) Air density kg/mm3 
    g_magnitude = 9810.
    g = Constant((0.0, g_magnitude, 0.0))  # Gravity vector in mm/s2 (downwards)
    
    root_mesh = "/mnt/c/Users/angus/Downloads/CORNELL-NEWGEO/PIG5/ARDSnet/medium/FEniCS/"
    
    mesh = dolfin.Mesh()
        
    # Load tetraedral mesh
    hdf = dolfin.HDF5File(mesh.mpi_comm(), root_mesh+'tetrahedral_mesh.h5', "r")
    hdf.read(mesh, "/mesh", False)
    # Load markers
    boundary_markers = dolfin.MeshFunction("size_t", mesh, mesh.topology().dim() - 1)
    hdf.read(boundary_markers, "/boundary_markers")
    hdf.close()
    
    # Path towards the current porosity data
    porosity_path = root_mesh+"phi0.xml.gz"
    
    if os.path.isfile(porosity_path):
        print("Porosity file found")
    else:
        print("Porosity file not found")
        
    # Define porosity as MeshFunctions
    phi = MeshFunction("double", mesh, porosity_path)
        
    # Code for C++ evaluation of permeability (conductivity)
    porosity_code = """
            
    #include <pybind11/pybind11.h>
    #include <pybind11/eigen.h>
    namespace py = pybind11;
            
    #include <dolfin/function/Expression.h>
    #include <dolfin/mesh/MeshFunction.h>
            
    class Porosity : public dolfin::Expression
    {
     public:
            
         // Create expression with 1 component
         Porosity() : dolfin::Expression(1) {}
         
         // Function for evaluating expression on each cell
         void eval(Eigen::Ref<Eigen::VectorXd> values, Eigen::Ref<const Eigen::VectorXd> x, const ufc::cell& cell) const override
         {
          const uint cell_index = cell.index;
          values[0] = (*phi)[cell_index];
          }
            
         // The data stored in mesh functions
              std::shared_ptr<dolfin::MeshFunction<double>> phi;
            
     };
            
     PYBIND11_MODULE(SIGNATURE, m)
    {
    py::class_<Porosity, std::shared_ptr<Porosity>, dolfin::Expression>
    (m, "Porosity")
    .def(py::init<>())
    .def_readwrite("phi", &Porosity::phi);
    }
            
    """
            
    phi_code = dolfin.CompiledExpression(compile_cpp_code(porosity_code).Porosity(),
                                   phi=phi, degree=0)
        
    phi = phi_code[0]
    
    # ---------------------- function spaces ----------------------
    P2 = VectorElement("Lagrange", mesh.ufl_cell(), 2)
    P1 = FiniteElement("CG", mesh.ufl_cell(), 1)
    TH = P2*P1 # Taylor-Hood
    W = FunctionSpace(mesh, TH)
    
    # Functions for displacement and pressure
    w = dolfin.Function(W)
    u, p = dolfin.split(w)
    
    # Test and trial functions
    _u, _p = dolfin.TestFunctions(W)
    du = dolfin.TrialFunction(W) 
    
    # Define a placeholder for a (potentially) spatially variable phi0 
    G = FunctionSpace(mesh,"CG",1)
            
    # Define geometric measures and limit quadrature degree
    dx = dolfin.Measure("dx", domain=mesh)
    ds = Measure('ds', domain=mesh, subdomain_data=boundary_markers)
    dx = dx(degree=3)
    ds = ds(degree=3)
        
    dolfin.info("Num DOFs {}".format(W.dim()))
    
    # ---------------------- kinematics & constitutive ----------------------
    
    # Determine the first Piola Kirchoff tensor
    if constitutive_model == 'birzle':
        sigma,F,J = stress_bir2019(u,p,c=0.3567*scaling_factor)
    elif constitutive_model == 'ma':
        sigma,F,J = stress_ma_inv(u,p, c=2.0*scaling_factor)
    else:
        raise Exception("Wrong constitutive model selection")
    
    # Composite density term in deformed configuration
    R = (J-phi)*rho_t + phi*rho_a
    
    # Flux
    if activate_gravity:
        q = -kappa*(grad(p)+rho_a*g)
    else:
        q = -kappa*grad(p)
        
    if activate_pleural_pressure:
        # Retrieve geometry bounds
        _, y_min, _ = mesh.coordinates().min(axis=0) 
        _, y_max, _ = mesh.coordinates().max(axis=0) # 
        
        # Define the pressures being applied
        p_max = 0 # transform cmH2O into kPa
        p_min = dp / 10.1972 # Forced to be zero
        
        # Note that the lung is 'upside down' and the ventral region occurs
        # at y_min and and the dorsal at y_max.
        p_expr = Expression(
            "p_min + (p_max - p_min)*(y_max-x[1])/(y_max - y_min)",
            degree=1,
            p_max=p_max,
            p_min=p_min,
            y_min=y_min,
            y_max=y_max
        ) 
        
        Qp = FunctionSpace(mesh,"CG",1)
        p_test = interpolate(p_expr, Qp)
        
        with XDMFFile(mesh.mpi_comm(), destination_folder+"pressure-field.xdmf") as xdmf:
            xdmf.write(p_test, 0.0)
        
        # Define a normal function
        n = FacetNormal(mesh)
    
    F0 = dolfin.inner(u,_u)*K_inf*dolfin.ds(subdomain_data=boundary_markers,
                                          subdomain_id=3) # Dorsal support  
    
    
    # Residual: mechanical + body force + incompressibility (pressure) equation
    Res = inner(sigma, grad(_u))*dx - inner(q, grad(_p))*dx + F0 #+ F2 #+  F1
    
    if activate_gravity:
        Res -=  R*dot(g, _u)*dx 
    
    if activate_pleural_pressure:
        F3 = dolfin.inner(p_test*n,_u)* dolfin.ds(subdomain_data=boundary_markers,
                                              subdomain_id=2) # Chest wall
        
        Res -= F3
        
    # Jacobian (derivative of residual w.r.t the mixed unknown w in direction du)
    Jac = derivative(Res, w, du)
    
    # Build the problem
    problem = NonlinearVariationalProblem(Res, w, J=Jac)
    solver = NonlinearVariationalSolver(problem)
    
    # First solver parameter definition
    solver_parameters = {"nonlinear_solver":"snes",
                         "snes_solver":{"linear_solver":"mumps",
                                        "relative_tolerance":1e-6,
                                        "absolute_tolerance":1e-8,
                                        "maximum_iterations":60,
                                        "line_search":"bt",
                                        "report":True,
                                        "error_on_nonconvergence":True,
                                        "preconditioner":"none"}
                         }
    
    # First solver parameter definition
    solver.parameters.update(solver_parameters)
    # Solve 
    solver.solve()
    
    # Define output spaces
    T = dolfin.TensorFunctionSpace(mesh, "CG", 1) 
    Q = dolfin.FunctionSpace(mesh, 'CG', 1)
    V = dolfin.VectorFunctionSpace(mesh, "Lagrange", 1)  ##
    
    # Extract solution components
    u, p = w.split()
    u.rename("Displacement", "")
    p.rename("Pressure", "")
    
    # Kinematics
    I = Identity(len(u))
    F = inv(I + grad(u))
    C = F.T*F
    J = det(F)
    
    # Compute the variables again (why?)
    if constitutive_model == 'birzle':
        sigma,F,J = stress_bir2019(u,p,c=0.3567*scaling_factor)
    elif constitutive_model == 'ma':
        sigma,F,J = stress_ma_inv(u,p, c=2.0*scaling_factor)
    else:
        raise Exception("Wrong constitutive model selection")
        
    # Convert to Cauchy stress for von Mises
    #sigma = (1.0/J) * P * F.T
    
    # Determine hydrostatic pressure
    P_hyd = -1./3.*tr(sigma)*10.1972 # in cmH2O
    P_hyd_ = project(P_hyd, Q)
    P_hyd_.rename("Hydrostatic pressure (cmH2O)","")
    
    # Von Mises stress
    von_mises = sqrt(
        0.5 * ((sigma[0,0]-sigma[1,1])**2
               + (sigma[1,1]-sigma[2,2])**2
               + (sigma[2,2]-sigma[0,0])**2)
        + 3.0*(sigma[0,1]**2 + sigma[1,2]**2 + sigma[2,0]**2)
    )
    VM = project(von_mises, Q)   # scalar CG field
    VM.rename("Von Mises stress", "")
    
    # Deformation gradient
    F_out = project(F, T)
    F_out.rename("F","")
    
    # Original (?) porosity
    phi0 = phi + 1 - J
    phi0_out = project(phi0, Q)
    phi0_out.rename("Phi_0","")
    
    # Eulerian porosity
    phi_out = project(phi, Q)
    phi_out.rename("Phi","")
    
    # Delta Gas fraction
    dgf = phi - phi0 # Tiene sentido? Quizás no
    dgf_out = project(dgf, Q)
    dgf_out.rename("Delta Gas Fraction","")
    
    # Jacobian
    Jproj = project(J, Q)
    Jproj.rename("Jacobian", "")
    
    # Export to XDMF
    t = 0.0 # Dummy
    # Create one .pvd file per variable
    F_file = File(output_to + "F.pvd")
    P_hyd_file = File(output_to + "HydrostaticPressure.pvd")
    u_file = File(output_to + "Displacement.pvd")
    p_file = File(output_to + "Pressure.pvd")
    phi0_file = File(output_to + "Phi0.pvd")
    phi_file = File(output_to + "Phi.pvd")
    J_file = File(output_to + "Jacobian.pvd")
    dgf_file = File(output_to + "DeltaGasFraction.pvd")
    
    # Write each variable to its file
    F_file << (F_out, t)
    P_hyd_file << (P_hyd_, t)
    u_file << (u, t)
    p_file << (p, t)
    phi0_file << (phi0_out, t)
    phi_file << (phi_out, t)
    J_file << (Jproj, t)
    dgf_file << (dgf_out, t)
    
if __name__ == "__main__":
    
    destination_folder = "./problem-8/"
    if not os.path.isdir(destination_folder):
        os.mkdir(destination_folder)
    
    # Constitutive model selection
    constitutive_model = 'birzle'
    
    # Output to
    output_to = destination_folder+constitutive_model+"-10/"
    
    # Create folder if it does not exist
    if not os.path.isdir(output_to):
        os.mkdir(output_to)
    
    
    cases ={'birzle':[(grav, pleural,sf) for grav in (True,False) for pleural in (True, False) for sf in (1.0, 1.0/0.3567, 2.0/0.3567)],
            'ma':[(grav, pleural,sf) for grav in (True,False) for pleural in (True, False) for sf in (1.0, 5.0/2.0, 10.0/2.0)]}
    
    exceptions = []
    for e, (grav, pleural, sf) in enumerate(cases[constitutive_model]):
        
        output_case = output_to+"case-%2.2i/"%e
        try:
            inverse_simulation(constitutive_model, output_case, 
                           scaling_factor=sf, 
                           activate_gravity=grav, 
                           activate_pleural_pressure=pleural,
                           dp=10.0)
        except:
            exceptions += ["case-%2.2i"%e]
            pass
    
    print("The following cases failed:")
    for exception in exceptions:
        print(" > %s"%exception)
            
        
            