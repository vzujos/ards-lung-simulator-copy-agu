# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 14:30:27 2025

@author: angus
"""

from dolfin import *
import numpy as np
import dolfin, os, shutil

def stress_bir2019(u, p,c=0.3567,beta=1.075):
    
    I = Identity(3)
    F = inv(I + grad(u))
    C=variable(F.T*F)
    I1C=variable(tr(C))
    I2C=0.5*((tr(C)**2)-tr(C*C))
    I3C=variable(det(C))
    J=variable(sqrt(I3C))
    I1raya=I1C*pow(I3C,-1/3)
    psi=c*(I1C-3)  +  (c/beta)*(pow(I3C,-beta)-1)+(278.2/1000)*pow((pow(I3C,-1/3)*I1C-3),3)+(5.766/1000)*pow((pow(I3C,1/3)-1),6)
    S=2*diff(psi,C)
    sigma = 1./J*F*S*F.T - p*I # Akin to what we had for P
    
    return sigma ,F, J

def stress_ma_inv(u, p, c=2.0, a = 0.43, b=-0.6):
    
    I = Identity(3)
    F = inv(I + grad(u))
    J = det(F)
    C=variable(F.T*F)
    E=0.5*(C-I)
    I1E=tr(E)
    I2E=0.5*((tr(E)**2)-tr(E*E))
    I3E=det(E)
    aa=Constant(a)
    bb=Constant(b)
    psi=c*exp(aa*I1E*I1E+bb*I2E)
    S=2*diff(psi,C)
    sigma = 1./J*F*S*F.T - p*I # Akin to what we had for P
    
    return sigma, F, J       

def inverse_analysis(mesh, boundary_markers, constitutive_model, 
                     output_to,
                     scaling_factor=1.0, kappa=1e5, K_inf=1e12, 
                     activate_gravity = True,
                     activate_pleural_pressure = True, dp=5.0):
    
    inv_output_to = output_to + "inverse-analysis/"
    
    if os.path.isdir(inv_output_to):
        shutil.rmtree(inv_output_to)
    os.mkdir(inv_output_to)
    
    # =============================================================================
    # Physical parameters
    # =============================================================================
    
    # Scale factor to previously considered reasonable values for lung tissue 
    if constitutive_model == 'ma':
        scaling_factor = 4.0 / 2.0
    elif constitutive_model == 'birzle':
        scaling_factor = 2.0 / 0.3567
    
    # Densities and gravity
    rho_t = Constant(1.0e-6)  # (tissue) Water density  kg/mm3
    rho_a = Constant(1.0e-9) # (air) Air density kg/mm3 
    g_magnitude = 9810.
    g = Constant((0.0, g_magnitude, 0.0))  # Gravity vector in mm/s2 (downwards)
    
    # Path towards the current porosity data
    porosity_path = root_mesh+"phi0.xml.gz"
    
    if os.path.isfile(porosity_path):
        print("Porosity file found")
    else:
        print("Porosity file not found")
    
    porosity_config = {'read_from_file':True,
                       'path_to_file':porosity_path,
                       'property_name':'End-expiratory porosity'}
    
    phi = define_property(mesh, porosity_config)
    
    # ---------------------- function spaces ----------------------
    P2 = VectorElement("Lagrange", mesh.ufl_cell(), 2)
    P1 = FiniteElement("CG", mesh.ufl_cell(), 1)
    TH = P2*P1 # Taylor-Hood
    W = FunctionSpace(mesh, TH)
    
    # Functions for displacement and pressure
    w = dolfin.Function(W)
    u, p = dolfin.split(w)
    
    # Test and trial functions
    _u, _p = dolfin.TestFunctions(W)
    du = dolfin.TrialFunction(W) 
    
    # Define a placeholder for a (potentially) spatially variable phi0 
    G = FunctionSpace(mesh,"CG",1)
            
    # Define geometric measures and limit quadrature degree
    dx = dolfin.Measure("dx", domain=mesh)
    ds = Measure('ds', domain=mesh, subdomain_data=boundary_markers)
    dx = dx(degree=3)
    ds = ds(degree=3)
        
    dolfin.info("Num DOFs {}".format(W.dim()))
    
    # ---------------------- kinematics & constitutive ----------------------
    
    # Determine the first Piola Kirchoff tensor
    if constitutive_model == 'birzle':
        sigma,F,J = stress_bir2019(u,p,c=0.3567*scaling_factor)
    elif constitutive_model == 'ma':
        sigma,F,J = stress_ma_inv(u,p, c=2.0*scaling_factor)
    else:
        raise Exception("Wrong constitutive model selection")
    
    # Composite density term in deformed configuration
    R = (J-phi)*rho_t + phi*rho_a
    
    # Flux
    if activate_gravity:
        q = -kappa*(grad(p)+rho_a*g)
    else:
        q = -kappa*grad(p)
        
    if activate_pleural_pressure:
        # Retrieve geometry bounds
        _, y_min, _ = mesh.coordinates().min(axis=0) 
        _, y_max, _ = mesh.coordinates().max(axis=0) # 
        
        # Define the pressures being applied
        p_max = 0 # transform cmH2O into kPa
        p_min = dp / 10.1972 # Forced to be zero
        
        # Note that the lung is 'upside down' and the ventral region occurs
        # at y_min and and the dorsal at y_max.
        p_expr = Expression(
            "p_min + (p_max - p_min)*(y_max-x[1])/(y_max - y_min)",
            degree=1,
            p_max=p_max,
            p_min=p_min,
            y_min=y_min,
            y_max=y_max
        ) 
        
        Qp = FunctionSpace(mesh,"CG",1)
        p_test = interpolate(p_expr, Qp)
        
        with XDMFFile(mesh.mpi_comm(), destination_folder+"pressure-field.xdmf") as xdmf:
            xdmf.write(p_test, 0.0)
        
        # Define a normal function
        n = FacetNormal(mesh)
    
    F0 = dolfin.inner(u,_u)*K_inf*dolfin.ds(subdomain_data=boundary_markers,
                                          subdomain_id=3) # Dorsal support  
    
    
    
    # Residual: mechanical + body force + incompressibility (pressure) equation
    Res = inner(sigma, grad(_u))*dx - inner(q, grad(_p))*dx + F0 #+ F2 #+  F1
    
    if activate_gravity:
        Res -=  R*dot(g, _u)*dx 
    
    if activate_pleural_pressure:
        F3 = dolfin.inner(p_test*n,_u)* dolfin.ds(subdomain_data=boundary_markers,
                                              subdomain_id=2) # Chest wall
        
        Res -= F3
        
    # Jacobian (derivative of residual w.r.t the mixed unknown w in direction du)
    Jac = derivative(Res, w, du)
    
    # Build the problem
    problem = NonlinearVariationalProblem(Res, w, J=Jac)
    solver = NonlinearVariationalSolver(problem)
    
    # First solver parameter definition
    solver_parameters = {"nonlinear_solver":"snes",
                         "snes_solver":{"linear_solver":"mumps",
                                        "relative_tolerance":1e-6,
                                        "absolute_tolerance":1e-8,
                                        "maximum_iterations":60,
                                        "line_search":"bt",
                                        "report":True,
                                        "error_on_nonconvergence":True,
                                        "preconditioner":"none"}
                         }
    
    # First solver parameter definition
    solver.parameters.update(solver_parameters)
    # Solve 
    solver.solve()
    
    # Define output spaces
    T = dolfin.TensorFunctionSpace(mesh, "CG", 1) 
    Q = dolfin.FunctionSpace(mesh, 'CG', 1)
    V = dolfin.VectorFunctionSpace(mesh, "Lagrange", 1)  ##
    
    # Extract solution components
    u, p = w.split()
    u.rename("Displacement", "")
    p.rename("Pressure", "")
    
    # Kinematics
    I = Identity(len(u))
    F = inv(I + grad(u))
    C = F.T*F
    J = det(F)
    
    # Compute the variables again (why?)
    if constitutive_model == 'birzle':
        sigma,F,J = stress_bir2019(u,p,c=0.3567*scaling_factor)
    elif constitutive_model == 'ma':
        sigma,F,J = stress_ma_inv(u,p, c=2.0*scaling_factor)
    else:
        raise Exception("Wrong constitutive model selection")
        
    # Convert to Cauchy stress for von Mises
    #sigma = (1.0/J) * P * F.T
    
    # Determine hydrostatic pressure
    P_hyd = -1./3.*tr(sigma)*10.1972 # in cmH2O
    P_hyd_ = project(P_hyd, Q)
    P_hyd_.rename("Hydrostatic pressure (cmH2O)","")
    
    # Von Mises stress
    von_mises = sqrt(
        0.5 * ((sigma[0,0]-sigma[1,1])**2
               + (sigma[1,1]-sigma[2,2])**2
               + (sigma[2,2]-sigma[0,0])**2)
        + 3.0*(sigma[0,1]**2 + sigma[1,2]**2 + sigma[2,0]**2)
    )
    VM = project(von_mises, Q)   # scalar CG field
    VM.rename("Von Mises stress", "")
    
    # Deformation gradient
    F_out = project(F, T)
    F_out.rename("F","")
    
    # Original (?) porosity
    phi0 = phi + 1 - J
    phi0_out = project(phi0, Q)
    phi0_out.rename("Phi_0","")
    
    # Eulerian porosity
    phi_out = project(phi, Q)
    phi_out.rename("Phi","")
    
    # Delta Gas fraction
    dgf = phi - phi0 # Tiene sentido? Quizás no
    dgf_out = project(dgf, Q)
    dgf_out.rename("Delta Gas Fraction","")
    
    # Jacobian
    Jproj = project(J, Q)
    Jproj.rename("Jacobian", "")


    t = 0.0 # Dummy
    # Create one .pvd file per variable
    F_file = File(inv_output_to + "F.pvd")
    P_hyd_file = File(inv_output_to + "HydrostaticPressure.pvd")
    u_file = File(inv_output_to + "Displacement.pvd")
    p_file = File(inv_output_to + "Pressure.pvd")
    phi0_file = File(inv_output_to + "Phi0.pvd")
    phi_file = File(inv_output_to + "Phi.pvd")
    J_file = File(inv_output_to + "Jacobian.pvd")
    dgf_file = File(inv_output_to + "DeltaGasFraction.pvd")
    
    # Write each variable to its file
    F_file << (F_out, t)
    P_hyd_file << (P_hyd_, t)
    u_file << (u, t)
    p_file << (p, t)
    phi0_file << (phi0_out, t)
    phi_file << (phi_out, t)
    J_file << (Jproj, t)
    dgf_file << (dgf_out, t)
    
    return F, det(F)

def define_property(mesh, property_config):
    
    read_from_file = property_config['read_from_file']
    path_to_property = property_config['path_to_file']
    property_name = property_config['property_name']
    
    
    if read_from_file:

        print("Variable %s simulation:"%property_name)
        print(" > File path: %s"%path_to_property)
        

        # Define tissue stiffness as MeshFunction
        property_value = MeshFunction("double", mesh, path_to_property)
    
        # Code for C++ evaluation of permeability (conductivity)
        code_outline = """
        
        #include <pybind11/pybind11.h>
        #include <pybind11/eigen.h>
        namespace py = pybind11;
        
        #include <dolfin/function/Expression.h>
        #include <dolfin/mesh/MeshFunction.h>
        
        class Value : public dolfin::Expression
        {
        public:
        
          // Create expression with 1 component
          Value() : dolfin::Expression(1) {}
        
          // Function for evaluating expression on each cell
          void eval(Eigen::Ref<Eigen::VectorXd> values, Eigen::Ref<const Eigen::VectorXd> x, const ufc::cell& cell) const override
          {
            const uint cell_index = cell.index;
            values[0] = (*property_value)[cell_index];
          }
        
          // The data stored in mesh functions
          std::shared_ptr<dolfin::MeshFunction<double>> property_value;
        
        };
        
        PYBIND11_MODULE(SIGNATURE, m)
        {
          py::class_<Value, std::shared_ptr<Value>, dolfin::Expression>
            (m, "Value")
            .def(py::init<>())
            .def_readwrite("property_value", &Value::property_value);
        }
        
        """
        
        processed_values = dolfin.CompiledExpression(compile_cpp_code(code_outline).Value(),
                                          property_value=property_value, degree=0)
    
        property_value = processed_values[0]
        
    else:    
        
        property_value = property_config['property_value']
        
        print("Constant %s simulation:"%property_name)
        print(" > Mean value = %.2f"%(property_value))
        
        H = FunctionSpace(mesh,"CG",1)
        h0 = Constant(property_value)
        property_value = interpolate(h0,H)
        
    return property_value
    

def initialize_mesh(root_mesh):
    
    mesh = dolfin.Mesh()
    
    # Load tetraedral mesh
    hdf = dolfin.HDF5File(mesh.mpi_comm(), root_mesh+'tetrahedral_mesh.h5', "r")
    hdf.read(mesh, "/mesh", False)
    # Load markers
    boundary_markers = dolfin.MeshFunction("size_t", mesh, mesh.topology().dim() - 1)
    hdf.read(boundary_markers, "/boundary_markers")
    hdf.close()
    
    subdomains = MeshFunction("size_t", mesh, root_mesh+"/Omega.xml.gz")

    return mesh, boundary_markers, subdomains
    
def inverse_analysis_step(mesh, boundary_markers, constitutive_model,
                     output_to,
                     scaling_factor=1.0, kappa=1e5, K_inf=1e12,
                     activate_gravity=True,
                     activate_pleural_pressure=True, dp=5.0,
                     nsteps=20):
    """
    Refactored to use load continuation (alpha from 0 -> 1) that scales gravity
    and pleural pressure. Returns the final mixed solution `w`.
    """

    inv_output_to = os.path.join(output_to, "inverse-analysis")
    if os.path.isdir(inv_output_to):
        # remove directory contents safely (simple approach)
        for fname in os.listdir(inv_output_to):
            os.remove(os.path.join(inv_output_to, fname))
    else:
        os.mkdir(inv_output_to)

    # =============================================================================
    # Physical parameters
    # =============================================================================

    # Scale factor to previously considered reasonable values for lung tissue
    if constitutive_model == 'ma':
        scaling_factor = 4.0 / 2.0
    elif constitutive_model == 'birzle':
        scaling_factor = 2.0 / 0.3567

    # Densities and gravity (units mm, g, mm/s^2 as in your script)
    rho_t = dolfin.Constant(1.0e-6)   # tissue density kg/mm^3
    rho_a = dolfin.Constant(1.0e-9)   # air density kg/mm^3
    g_magnitude = 9810.0
    g = dolfin.Constant((0.0, g_magnitude, 0.0))  # gravity vector (mm/s^2)

    # Path towards the current porosity data
    porosity_path = root_mesh+"phi0.xml.gz"
    
    if os.path.isfile(porosity_path):
        print("Porosity file found")
    else:
        print("Porosity file not found")
    
    porosity_config = {'read_from_file':True,
                       'path_to_file':porosity_path,
                       'property_name':'End-expiratory porosity'}
    
    phi = define_property(mesh, porosity_config)

    # ---------------------- function spaces ----------------------
    P2 = dolfin.VectorElement("Lagrange", mesh.ufl_cell(), 2)
    P1 = dolfin.FiniteElement("CG", mesh.ufl_cell(), 1)
    TH = dolfin.MixedElement([P2, P1])  # Taylor-Hood mixed element
    W = dolfin.FunctionSpace(mesh, TH)

    # Functions for displacement and pressure (w holds both)
    w = dolfin.Function(W, name="w")    # current solution (initial guess zeros)
    # split to obtain u and p (UFL objects that reference w)
    u, p = dolfin.split(w)

    # Test and trial functions for variational forms
    _u, _p = dolfin.TestFunctions(W)
    du = dolfin.TrialFunction(W)

    # Placeholder for spatially variable phi0
    G = dolfin.FunctionSpace(mesh, "CG", 1)

    # Measures and quadrature degree
    dx = dolfin.Measure("dx", domain=mesh)
    ds = dolfin.Measure('ds', domain=mesh, subdomain_data=boundary_markers)
    # limit quadrature degree if desired
    dx = dx(degree=3)
    ds = ds(degree=3)

    dolfin.info("Num DOFs {}".format(W.dim()))

    # ---------------------- kinematics & constitutive ----------------------
    # Determine sigma, F, J from chosen constitutive model (functions must return UFL objects)
    if constitutive_model == 'birzle':
        sigma, F, J = stress_bir2019(u, p, c=0.3567 * scaling_factor)
    elif constitutive_model == 'ma':
        sigma, F, J = stress_ma_inv(u, p, c=2.0 * scaling_factor)
    else:
        raise Exception("Wrong constitutive model selection")

    # Composite density term in deformed configuration (UFL)
    R = (J - phi) * rho_t + phi * rho_a

    # Flux - Darcy-like (kappa could be scalar or function)
    # gravity effect will be scaled by alpha via g_scaled below
    q_base = -kappa * dolfin.grad(p)

    # ---------------------- pleural pressure expression (base) --------------
    if activate_pleural_pressure:
        # Retrieve geometry bounds in y
        coords = mesh.coordinates()
        y_min = float(coords[:, 1].min())
        y_max = float(coords[:, 1].max())

        # p_max (kPa?), p_min forced to zero as in your original code
        p_max = 0.0
        p_min = dp / 10.1972
        p_expr_base = dolfin.Expression(
            "p_min + (p_max - p_min)*(y_max - x[1])/(y_max - y_min)",
            degree=1, p_max=p_max, p_min=p_min, y_min=y_min, y_max=y_max
        )

        Qp = dolfin.FunctionSpace(mesh, "CG", 1)
        p_test = dolfin.Function(Qp, name="pleural_base")
        # initialize (alpha will scale this later)
        p_test_local = dolfin.interpolate(p_expr_base, Qp)
        p_test.assign(p_test_local)

        # write base pressure to XDMF for record
        with dolfin.XDMFFile(mesh.mpi_comm(), os.path.join(inv_output_to, "pressure-field.xdmf")) as xdmf:
            xdmf.write(p_test, 0.0)

        # outward normal used for traction-like pleural application
        n = dolfin.FacetNormal(mesh)
    else:
        p_test = None
        n = dolfin.FacetNormal(mesh)

    # Support / dorsal constraint modeled with K_inf on subdomain id 3 (keeps logic)
    F0 = dolfin.inner(u, _u) * K_inf * dolfin.ds(subdomain_data=boundary_markers, subdomain_id=3)

    # ---------------------- set up continuation parameter alpha -------------
    alpha = dolfin.Constant(0.0)   # will be ramped from 0 -> 1

    # scaled gravity and pleural pressure will use alpha so Res depends on alpha symbolically
    g_scaled = alpha * g
    # scaled Darcy flux
    if activate_gravity:
        q = -kappa * (dolfin.grad(p) + alpha * rho_a * g)   # alpha*g multiplies only the gravity part
    else:
        q = q_base

    # scaled pleural pressure: we'll update the Function `p_test` in the loop
    # Build residual (depends on alpha via g_scaled and p_test Function)
    Res_mech = dolfin.inner(sigma, dolfin.grad(_u)) * dx        # internal virtual work
    Res_flow = -dolfin.inner(q, dolfin.grad(_p)) * dx           # Darcy flow weak term
    Res = Res_mech + Res_flow + F0

    if activate_gravity:
        Res -= R * dolfin.dot(g_scaled, _u) * dx

    if activate_pleural_pressure:
        # use p_test Function in the weak form (it will be updated each continuation step)
        # note subdomain_id=2 is chest wall in your original code
        Res -= dolfin.inner(p_test * alpha * n, _u) * dolfin.ds(subdomain_data=boundary_markers, subdomain_id=2)

    # Jacobian (derivative of Res w.r.t. mixed unknown `w` in direction `du`)
    Jac = dolfin.derivative(Res, w, du)

    # ---------------------- build solver ----------------------
    problem = dolfin.NonlinearVariationalProblem(Res, w, J=Jac)
    solver = dolfin.NonlinearVariationalSolver(problem)
    # First solver parameter definition
    solver_parameters = {"nonlinear_solver":"snes",
                         "snes_solver":{"linear_solver":"mumps",
                                        "relative_tolerance":1e-6,
                                        "absolute_tolerance":1e-8,
                                        "maximum_iterations":60,
                                        "line_search":"bt",
                                        "report":True,
                                        "error_on_nonconvergence":True,
                                        "preconditioner":"none"}
                         }
    
    # First solver parameter definition
    solver.parameters.update(solver_parameters)
    # ---------------------- continuation loop (alpha ramp) -----------------
    alphas = np.linspace(0.0, 1.0, nsteps + 1)
    DG0 = dolfin.FunctionSpace(mesh, 'DG', 0)
    J_proj = dolfin.Function(DG0, name='J')

    for i, a in enumerate(alphas[1:], start=1):
        a = float(a)
        dolfin.info(f"\n-- continuation step {i}/{nsteps}: alpha = {a:.3f} --")
        alpha.assign(a)

        # update pleural pressure field if active (scale base expression by alpha)
        if activate_pleural_pressure:
            # assign alpha * base_expression into p_test (so Res uses updated p_test)
            # Using interpolate ensures appropriate Function->Function copying
            p_tmp = dolfin.interpolate(dolfin.Expression(
                "alpha*(p_min + (p_max - p_min)*(y_max - x[1])/(y_max - y_min))",
                degree=1, alpha=a,
                p_max=float(p_expr_base.p_max),
                p_min=float(p_expr_base.p_min),
                y_min=float(p_expr_base.y_min),
                y_max=float(p_expr_base.y_max)
            ), Qp)
            p_test.vector()[:] = p_tmp.vector()[:]

        # attempt solve with current alpha (w provides initial guess)
        try:
            solver.solve()
        except:
            print("Solver failed at alpha =", a)
            break

        # compute and check J to ensure no element inversion occurred
        try:
            J_proj = dolfin.project(dolfin.det(dolfin.Identity(3) + dolfin.grad(dolfin.split(w)[0])), DG0)
            Jmin = float(J_proj.vector().min())
            Jmax = float(J_proj.vector().max())
        except Exception:
            # fallback: sample J at quadrature or approximate
            print("Warning: failed to project J; skipping J diagnostic")
            Jmin = np.nan
            Jmax = np.nan

        dolfin.info(f"  Jmin = {Jmin:.6e}, Jmax = {Jmax:.6e}")
        if (not np.isfinite(Jmin)) or (Jmin <= 0.0):
            print("  ERROR: non-positive or non-finite Jacobian detected. Stopping continuation.")
            break

        # optional: write intermediate outputs
        if (i % max(1, nsteps // 5)) == 0 or i == nsteps:
            # write current pleural pressure and solution snapshot
            with dolfin.XDMFFile(mesh.mpi_comm(), os.path.join(inv_output_to, f"w_step_{i:03d}.xdmf")) as xf:
                xf.write(w, float(a))

    # ---------------------- final outputs -----------------------------------
    # save final solution and diagnostics
    with dolfin.XDMFFile(mesh.mpi_comm(), os.path.join(inv_output_to, "solution_final.xdmf")) as xf:
        xf.write(w, 1.0)

    # Extract solution components
    u, p = w.split()
    u.rename("Displacement", "")
    p.rename("Pressure", "")
    
    # Kinematics
    I = Identity(len(u))
    F = inv(I + grad(u))
    
    # return final mixed function (you can split to get u,p)
    return F, det(F)

if __name__ == '__main__':
    
    destination_folder = "./problem-9/"
    if not os.path.isdir(destination_folder):
        os.mkdir(destination_folder)
    
    root_mesh = "/mnt/c/Users/angus/Downloads/CORNELL-NEWGEO/PIG5/ARDSnet/medium/FEniCS/"
    
    output_to = destination_folder
    constitutive_model = 'birzle'
    scaling_factor = 1.8/0.3567
    dp = 10.0
    
    #Define some dolfin parameters
    dolfin.parameters["form_compiler"]["cpp_optimize"] = True
    dolfin.parameters["form_compiler"]["representation"] = "uflacs"
    dolfin.parameters["form_compiler"]["quadrature_degree"] = 4
    dolfin.parameters["allow_extrapolation"] = True 
    dolfin.parameters["form_compiler"]["optimize"] = True 
    
    mesh, boundary_markers, subdomains = initialize_mesh(root_mesh)
    
    compare = True
        
    try:
        F2, J2_ = inverse_analysis_step(mesh, boundary_markers, constitutive_model, 
                             output_to,
                             scaling_factor=scaling_factor, kappa=1e5, K_inf=1e12, 
                             activate_gravity = True,
                             activate_pleural_pressure = True, dp=dp,
                             nsteps=20)
    except:
        print("Step-loading formulation failed")
        compare = False
        
    try:
        F1, J1_ = inverse_analysis(mesh, boundary_markers, constitutive_model, 
                             output_to,
                             scaling_factor=scaling_factor, kappa=1e5, K_inf=1e12, 
                             activate_gravity = True,
                             activate_pleural_pressure = True, dp=dp)
    except:
        print("Regular analysis failed")
        compare = False
        
    if compare:
        # Build CG1 space
        V = FunctionSpace(mesh, "CG", 1)
    
        # --- Project J = det(F) onto V ---
        J1 = project(det(J1_), V)
        J2 = project(det(J2_), V)
    
        # Difference
        Jdiff = Function(V)
        Jdiff.vector()[:] = J1.vector()[:] - J2.vector()[:]
        
        # L2 norm of the difference
        L2_error = sqrt(assemble(inner(Jdiff, Jdiff) * dx))
        
        # Min/max values
        J1_min = J1.vector().min()
        J1_max = J1.vector().max()
        
        J2_min = J2.vector().min()
        J2_max = J2.vector().max()
        
        Jdiff_min = Jdiff.vector().min()
        Jdiff_max = Jdiff.vector().max()
        
        # Print results
        print("\n===== Jacobian Comparison =====")
        print(f"L2 norm of difference: {L2_error:.6e}")
        print(f"J1: min = {J1_min:.6e}, max = {J1_max:.6e}")
        print(f"J2: min = {J2_min:.6e}, max = {J2_max:.6e}")
        print(f"Difference: min = {Jdiff_min:.6e}, max = {Jdiff_max:.6e}")
        print("================================\n")
