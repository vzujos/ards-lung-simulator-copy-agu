# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 14:30:27 2025

@author: angus
"""

from dolfin import *
import numpy as np
import dolfin, os


destination_folder = "./problem-1/"
if not os.path.isdir(destination_folder):
    os.mkdir(destination_folder)

#Define some dolfin parameters
dolfin.parameters["form_compiler"]["cpp_optimize"] = True
dolfin.parameters["form_compiler"]["representation"] = "uflacs"
dolfin.parameters["form_compiler"]["quadrature_degree"] = 4
dolfin.parameters["allow_extrapolation"] = True 
dolfin.parameters["form_compiler"]["optimize"] = True 


# Incompressible Neo-Hookean over a cube of side 200 mm

# ---------------------- geometry / mesh ----------------------
L = 25.0 # mm
Lx = L
Ly = 5*L
Lz = L

# mesh subdivisions (adjust for accuracy / speed)
mesh = Mesh()
with XDMFFile(destination_folder+"forward_gravity_cube.xdmf") as infile:
    infile.read(mesh)

# ---------------------- function spaces ----------------------
P2 = VectorElement("Lagrange", mesh.ufl_cell(), 2)
P1 = FiniteElement("CG", mesh.ufl_cell(), 1)
TH = P2*P1 # Taylor-Hood
W = FunctionSpace(mesh, TH)

# Functions for displacement and pressure
w = dolfin.Function(W)
u, p = dolfin.split(w)

# Test and trial functions
_u, _p = dolfin.TestFunctions(W)
du = dolfin.TrialFunction(W) 

# ---------------------- material parameters ----------------------
mu = 1.66 # (kPa) | Lame constant | Reference Concha et al. 2018 

# gravity parameters
rho = Constant(1.0e-6)        # Water density  kg/mm3
g = Constant((0.0, -9810, 0.0))  # Gravity vector in mm/s2 (downwards)

# ---------------------- boundary markers ----------------------
from dolfin import MeshFunction, Measure

# Generate boundaries for the bottom face
boundaries = MeshFunction("size_t", mesh, mesh.topology().dim()-1)
boundaries.set_all(0)

#Bottom face
class YMin(SubDomain):
    def inside(self, x, on_boundary):
        return near(x[1], 0.0)

# Marking the faces as min and max
ymin = YMin()
ymin.mark(boundaries, 1)

# Define geometric measures and limit quadrature degree
dx = dolfin.Measure("dx", domain=mesh)
ds = Measure('ds', domain=mesh, subdomain_data=boundaries)
dx = dx(degree=3)
ds = ds(degree=3)
    
dolfin.info("Num DOFs {}".format(W.dim()))

# ---------------------- kinematics & constitutive ----------------------
I = Identity(3)
# u, p are the symbolic split(w)
F = variable(inv(grad(u)+I))
J = det(F)
C = variable(F.T*F)
psi = mu/2*(tr(C)-3) - p*(J-1)
S = 2*diff(psi, C)
P = F*S- J*p*inv(F).T

# Residual: mechanical + body force + incompressibility (pressure) equation
Res = inner(P, grad(_u))*dx - rho*dot(g, _u)*dx + (J - 1.0)*_p*dx

# Jacobian (derivative of residual w.r.t the mixed unknown w in direction du)
Jac = derivative(Res, w, du)

# Define the boundary conditions
tol = 1e-6

# Lock one corner (x=0, y=0, z=0) in x and z to avoid rigid body motion 
class CornerA(SubDomain): 
    def inside(self, x, on_boundary): 
        return near(x[0], 0.0) and near(x[1], 0.0) and near(x[2], 0.0) 
    
class CornerB(SubDomain):
    def inside(self, x, on_boundary):
        return near(x[0], Lx) and near(x[1], 0.0) and near(x[2], 0.0)
    
class CornerC(SubDomain):
    def inside(self, x, on_boundary):
        return near(x[2], Lz) and near(x[1], 0.0) and near(x[0], 0.0)
    
cA = CornerA(); cB = CornerB(); cC = CornerC();
bc_cornerA_x = DirichletBC(W.sub(0).sub(0), Constant(0.0), cA, method="pointwise") 
bc_cornerA_z = DirichletBC(W.sub(0).sub(2), Constant(0.0), cA, method="pointwise")
bc_cornerB_z = DirichletBC(W.sub(0).sub(2), Constant(0.0), cB, method="pointwise")
bc_cornerC_x = DirichletBC(W.sub(0).sub(0), Constant(0.0), cC, method="pointwise") 
bc_ymin_y = DirichletBC(W.sub(0).sub(1), Constant(0.0), boundaries, 1)

# construir lista final de BCs (quita el corner BC anterior si lo tenías)
bcs = [bc_ymin_y, 
       bc_cornerA_x, bc_cornerA_z,
       bc_cornerC_x, bc_cornerB_z]

# Build the problem
problem = NonlinearVariationalProblem(Res, w, bcs, Jac)
solver = NonlinearVariationalSolver(problem)

# First solver parameter definition
prm = solver.parameters
prm['nonlinear_solver'] = 'newton'
prm['newton_solver']['maximum_iterations'] = 50
prm['newton_solver']['relative_tolerance'] = 1e-8
prm['newton_solver']['absolute_tolerance'] = 1e-10
prm['newton_solver']['linear_solver'] = 'mumps'   # o 'mumps'
prm['newton_solver']['preconditioner'] = 'default'
prm['newton_solver']['report'] = True
#prm['newton_solver']['line_search'] = 'basic'

solver_parameters = {"nonlinear_solver":"snes",
                     "snes_solver":{"linear_solver":"lu",
                                    "relative_tolerance":1e-6,
                                    "absolute_tolerance":1e-8,
                                    "maximum_iterations":60,
                                    "line_search":"bt",
                                    "report":True,
                                    "error_on_nonconvergence":True,
                                    "preconditioner":"default"}
                     }

# First solver parameter definition
solver.parameters.update(solver_parameters)
# Solve 
solver.solve()

T = dolfin.TensorFunctionSpace(mesh, "CG", 1) 
Q = dolfin.FunctionSpace(mesh, 'CG', 1)
V = dolfin.VectorFunctionSpace(mesh, "Lagrange", 1)  ##


# Extract solution components
u, p = w.split()
u.rename("u", "Displacement")
p.rename("p", "Pressure")

# --- Split solution ---
u, p = w.split()
u.rename("displacement", "")
p.rename("pressure", "")   # this is hydrostatic/Lagrange multiplier

# --- Kinematics ---
I = Identity(len(u))
F = inv(I + grad(u))
C = F.T*F
J = det(F)

# --- Material stress (Piola) ---
FinvT = inv(F).T
P = mu*F - p*J*FinvT

# Convert to Cauchy stress for von Mises
sigma = (1.0/J) * P * F.T

# --- Von Mises stress ---
von_mises = sqrt(
    0.5 * ((sigma[0,0]-sigma[1,1])**2
           + (sigma[1,1]-sigma[2,2])**2
           + (sigma[2,2]-sigma[0,0])**2)
    + 3.0*(sigma[0,1]**2 + sigma[1,2]**2 + sigma[2,0]**2)
)

VM = project(von_mises, Q)   # scalar CG field
VM.rename("von_mises", "")

# --- Jacobian J field ---
Jproj = project(J, Q)
Jproj.rename("jacobian", "")

# --- Export to PVD ---
File(destination_folder+"inv_u.pvd") << u
File(destination_folder+"inv_p.pvd") << p
File(destination_folder+"inv_von_mises.pvd") << VM
File(destination_folder+"inv_jacobian.pvd") << Jproj

ALE.move(mesh,u)
with XDMFFile(destination_folder+"inverse_gravity_cube.xdmf") as xdmf:
    xdmf.write(mesh)