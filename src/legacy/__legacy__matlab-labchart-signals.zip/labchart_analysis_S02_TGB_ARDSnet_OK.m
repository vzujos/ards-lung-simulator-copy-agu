
path_to_adicht = "C:\Users\angus\Downloads\CORNELL-NEWGEO\Signals\Signals_sub02-tgb.adicht"
subject_name = "PIG2";
protocol="ARDSnet";
output_filename =  strcat("C:\Users\angus\Downloads\CORNELL-GEOM\test\Signals\",subject_name,"-",protocol,".mat");

% Read adicht file
adicht  = adi.readFile(path_to_adicht);

% Try and get Peso

%%  SAMPLING FOR PCV
% ABOUT 10 cycles with reasonable Peso variations [-5,-4]
%sel = 5;
%i0 = 1101000-1;
%i1 = 1151000-1;
%time = (0:(i1-i0))*0.0025 ;% Constant comes from the sampling time at the adicht file

% Alternative Paw_high = ~ 20 cmH2O Paw_low ~ 2 cmH2O; Peso ~ [-2,0]
% sel = 8;
% i0 = 1000-1;
% i1 = 31000-1;

%% SAMPLING FOR VCV
% Over 10 cycles, with Peso varying in a reasonable way [-2,2]
% sel = 8;
% i0 = 3951000-1;
% i1 = 3981000-1;

%%

sel = 7;
i0 = 3970000-1;
i1 = i0 + 10000;
time = (0:(i1-i0))*0.0025;

Paw = adicht.getChannelByName('Paw');
Paw_data = Paw.getData(sel);
Paw_rdata = Paw_data(i0:i1);

% Pressure-related plot
close(figure(1));
close(figure(2));
figure(1);
plot(time,Paw_rdata);
xlabel("Time (s)")
ylabel("Airway pressure (cmH2O)")
%xlim([0,10])
yyaxis right
Peso = adicht.getChannelByName('Peso');
Peso_data = Peso.getData(sel);
Peso_rdata = Peso_data(i0:i1);
Peso_sdata = smoothdata(Peso_rdata,1,"movmean",8);
Peso_sdata = smoothdata(Peso_sdata,1,"movmedian",16);
plot(time,Peso_sdata);
xlabel("Time (s)")
ylabel("Esophageal pressure (cmH2O)")
%xlim([0,10])
ylim([-5,5])

%% Data selection

sel = 7;  
i0 = 3970000-1;
fitter = 685;
i0 = i0 + fitter;
i1 = i0+10001;
time = (0:(i1-i0))*0.0025; % Constant comes from the sampling time at the adicht file

%sel = 11;  % Selected channel for VCV-PEEP10
%i0 = 1580000;
%fitter = 581;
%i0 = i0 + fitter;
%i1 = 1620000-1;
%time = (0:(i1-i0))*0.0025; % Constant comes from the sampling time at the adicht file


%% Airway pressure

Paw = adicht.getChannelByName('Paw');
Paw_data = Paw.getData(sel);
Paw_rdata = Paw_data(i0:i1);

plot(time,Paw_rdata);
xlabel("Time (s)")
ylabel("Airway pressure (cmH2O)")
xlim([0,10])
ylim([0,35])

%% Esophageal pressure

Peso = adicht.getChannelByName('Peso');
Peso_data = Peso.getData(sel);
Peso_rdata = Peso_data(i0:i1);
%Peso_sdata = smoothdata(Peso_rdata,1,"movmean",8);
%Peso_sdata = smoothdata(Peso_sdata,1,"movmedian",16);
Peso_sdata = lowpass(Peso_rdata,0.01);
plot(time,Peso_sdata);
xlabel("Time (s)")
ylabel("Esophageal pressure (cmH2O)")
xlim([0,10])
%ylim([1,4])


%% Esophageal pressure and low-pass filter


y = Peso_rdata(1:4000);
x = time(1:4000);
z1 = lowpass(y,0.01);


close(figure(1));
close(figure(2));
figure(1);
plot(x,z1)
%ylim([0.5,4.5])
%yline(mean(z1),"--","Mean flow")
ylabel("Esophageal pressure (cmH2O)")
xlabel("Time (s)")

%% Flow

Flow = adicht.getChannelByName('Flow');
flow_data = Flow.getData(sel);
flow_data = flow_data/60.; % Changing units
correction = -0.011 ;%-0.00946759; % Obtained by measuring the non-zero value of the raw signal in the inspiratory pause
flow_data = flow_data + correction; % Note the correction;
flow_rdata = flow_data(i0:i1);

plot(time,flow_rdata);
xlabel("Time (s)")
ylabel("Flow (L/s)")
xlim([0,10])

%% Volume
close(figure);
figure(1);
volume = transpose(cumtrapz(flow_rdata))*0.0025;
plot(time,volume);
xlim([0,10])
xlabel("Time (s)")
ylabel("Volume (L)")

%% Compute transpulmonar pressure
% Ptp ~= Pao - Peso

Ptp_rdata = Paw_rdata - Peso_rdata;
plot(time,smoothdata(Ptp_rdata,"movmedian",10));

%% BVilla's equations

X = [transpose(volume),flow_rdata,ones(size(flow_rdata))];

A_mid = inv(transpose(X)*X)

%%  BVilla's equations; Respiratory system properties
A = A_mid*transpose(X)*Paw_rdata;
E_rs = A(1); % E, R, P0  % 33.3124 cmH2O/L
C_rs = 1/E_rs*1000;  %  30.0188 mL/cmH2O
R_rs = A(2);  % 12.2729 cmH2O/L/s
PEEP_reg = A(3); % 10.7871 cmH2O

%% BVilla's equations; Chest-wall properties

A = A_mid*transpose(X)*Peso_sdata;
E_cw = A(1); % E, R, P0  % 6.5265 cmH2O/L
C_cw = 1/E_cw*1000;  % 153.2208 mL/cmH2O
R_cw = A(2);  % 0.4857 cmH2O/L/s
Peso_p0_reg = A(3); % 4.1641 cmH2O

%% BVilla's equations; Lung properties 

A = A_mid*transpose(X)*(Paw_rdata-Peso_sdata);
E_L = A(1); % E, R, P0  % 26.7859 cmH2O/L
C_L = 1/E_L*1000;  % 37.3331 mL/cmH2O
R_L = A(2);  % 11.7872 cmH2O/L/s
Ptp_p0_reg = A(3); % 6.6230 cmH2O

%% Export data

save(output_filename, "Paw_rdata","flow_rdata","Peso_sdata","volume","time");

%% Generate reconstructed figures

P_aw_reconstructed = E_rs*transpose(volume)+R_rs*flow_rdata+PEEP_reg;
P_eso_reconstructed = E_cw*transpose(volume)+R_cw*flow_rdata+Peso_p0_reg;
P_tp_reconstructed = E_L*transpose(volume)+R_L*flow_rdata+Ptp_p0_reg;

%% Reconstructing airway pressure

close all;
figure(1);
plot(time,Paw_rdata)
hold on;
plot(time,P_aw_reconstructed)
xlim([0,10])
ylim([0,35])
legend("Airway pressure", "Reconstructed signal","location","southwest")
xlabel("Time (s)")
ylabel("Pressure (cmH2O)")

%% Reconstructing esophageal pressure

close all;
figure(1);
plot(time,Peso_sdata)
hold on;
plot(time,P_eso_reconstructed)
xlim([0,10])
ylim([0.5,4.5])
legend("Esophageal pressure", "Reconstructed signal","location","southwest")
xlabel("Time (s)")
ylabel("Pressure (cmH2O)")

%% Reconstructing esophageal pressure

close all;
figure(1);
plot(time,Paw_rdata-Peso_sdata)
hold on;
plot(time,P_tp_reconstructed)
xlim([0,10])
ylim([0,35])
legend("Transpulmonary pressure", "Reconstructed signal","location","southwest")
xlabel("Time (s)")
ylabel("Pressure (cmH2O)")
