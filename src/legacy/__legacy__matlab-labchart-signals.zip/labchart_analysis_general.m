subject_id = "PIG2";
treatment = "ARDSnet";

p = signal_setup(subject_id, treatment);

%% Load the data
adicht  = adi.readFile(p.path);

%% Analysis setup

channel = p.channel; % Extract data from the proposed channel
Flow = adicht.getChannelByName('Flow'); % Load the flow data
Paw = adicht.getChannelByName('Paw'); % Load the airway pressure
Peso = adicht.getChannelByName('Peso'); % Esophageal pressure


flow_data = Flow.getData(channel) / 60;  % Convert to L/s
Paw_data = Paw.getData(channel);
Peso_data = Peso.getData(channel);


%% Scouting setup

% User-defined window duration (in seconds)
window_duration = 3.00;  % Default value; change as needed
dt = 0.0025; % Sampling time [s]
Fs = 1/dt;   % Sampling frequency [Hz]

% Number of samples in each window
window_length = round(window_duration / dt);

% Restrict search scope
scope  = 500000;         % Length of the segment to inspect
istart = 1+scope*15;         % Starting index (manually chosen)
%istart = 8000000;
%scope = 200000;
iend   = min(istart + scope - 1, signal_end);  % Ending index (bounded by data)
signal_end = size(flow_data,1);

% Validate the range
if (iend - istart + 1) < window_length
    error("Selected scope is too short for the analysis window.");
end

% User-defined threshold for Paw swing (in cmH2O)
Paw_threshold = 10;  % Adjust as needed

% Initialize storage
result = struct();

results = struct('i0', {}, 'i1', {}, 'delta_volume', {}, ...
                 'flow', {}, 'volume', {}, 'Paw', {}, 'Peso', {});

%% Loop over windows

for i0 = istart : window_length : (iend - window_length + 1)
    i1 = i0 + window_length - 1;

    % Extract subwindow of flow and pressures
    window_flow = flow_data(i0:i1);
    window_paw = Paw_data(i0:i1);
    window_peso = Peso_data(i0:i1);
    
    % Integrate flow to get volume
    window_volume = cumtrapz(window_flow) * dt;

    % Compute max delta volume
    delta_volume = max(window_volume) - min(window_volume);

    % Store results
    result.i0 = i0;
    result.i1 = i1;
    result.delta_volume = delta_volume;
    result.flow = window_flow;
    result.volume = window_volume;
    result.Paw = window_paw;
    result.Peso = window_peso;

    results(end+1) = result;
end

%% Determine the best match


% Extract delta_volume and delta_Paw for each result
delta_volumes = arrayfun(@(r) r.delta_volume, results);
delta_Paws    = arrayfun(@(r) max(r.Paw) - min(r.Paw), results);

% Filter results that meet the Paw threshold
valid_idx = find(delta_Paws > Paw_threshold);

if isempty(valid_idx)
    error('No windows found with ΔPaw > %.1f cmH2O', Paw_threshold);
end

% Compute error from target volume for valid windows
volume_errors = abs(delta_volumes(valid_idx) - p.target_volume);

% Select the window with the smallest error
[~, min_err_idx] = min(volume_errors);
best_idx = valid_idx(min_err_idx);

% Select the best-matching result
best = results(best_idx);


% Remove other figures
close all;

% Define time vector for the selected window
time = (0:length(best.flow)-1) * dt;

% Create figure
figure;
tiledlayout(2,2);  % 2 rows, 2 columns

% 1. Paw
nexttile;
plot(time, best.Paw);
yline(0, '--k');  % Horizontal dashed black line at y = 0

xlabel('Time (s)');
ylabel('Paw (cmH2O)');
title('Airway Pressure');

% 2. Flow
nexttile;
plot(time, best.flow);
xlabel('Time (s)');
yline(0, '--k');  % Horizontal dashed black line at y = 0
ylabel('Flow (L/s)');
title('Flow');

% 3. Peso
nexttile;
window = 51;  % Must be odd
order = 3;    % Polynomial order
peso_filt = sgolayfilt(best.Peso, order, window);

plot(time, peso_filt);
xlabel('Time (s)');
ylabel('Peso (cmH2O)');
title('Esophageal Pressure');

% 4. Volume
nexttile;
plot(time, best.volume);
xlabel('Time (s)');
ylabel('Volume (L)');
title('Volume');

% Report match quality
fprintf('Best match found in window [%d:%d]\n', best.i0, best.i1);
fprintf(' → ΔVolume = %.4f L\n', best.delta_volume);
fprintf(' → Target  = %.4f L\n', p.target_volume);
fprintf(' → Error   = %.4f L\n', abs(best.delta_volume - p.target_volume));
fprintf(' → Rel. Error  = %.1f \n', abs(best.delta_volume - p.target_volume)/p.target_volume*100);

fprintf(' → ΔPaw    = %.2f cmH2O\n', max(best.Paw) - min(best.Paw));
fprintf('Total windows scouted: %d\n', numel(results));

%%

if false

    close all;
    % User-defined indices
    fixer = 600;
    i0 = 3122401 + fixer;
    i1 = 3123600 + fixer+400;  % example: i0 + window_length - 1
    
    % Time vector
    dt = 0.0025;
    time = (0:(i1 - i0)) * dt;
    
    % Extract signals
    window_flow = flow_data(i0:i1);
    window_paw = Paw_data(i0:i1);
    window_peso = Peso_data(i0:i1);

    window = 51;  % Must be odd
    order = 3;    % Polynomial order
    peso_filt = sgolayfilt(window_peso, order, window);
    window_volume = cumtrapz(window_flow) * dt;
    
    % Plotting
    figure;
    tiledlayout(2,2);
    
    % 1. Paw
    nexttile;
    plot(time, window_paw);
    ylim([0 max(window_paw)+2])
    xlabel('Time (s)');
    ylabel('Paw (cmH2O)');
    title('Airway Pressure');
    
    % 2. Flow
    nexttile;
    plot(time, window_flow);
    yline(0, '--k');
    xlabel('Time (s)');
    ylabel('Flow (L/s)');
    title('Flow');
    
    % 3. Peso
    nexttile;
    plot(time, peso_filt);
    xlabel('Time (s)');
    ylabel('Peso (cmH2O)');
    title('Esophageal Pressure');
    
    % 4. Volume
    nexttile;
    plot(time, window_volume);
    ylim([0,max(window_volume)+0.05])
    xlabel('Time (s)');
    ylabel('Volume (L)');
    title('Volume');

end