
path_to_adicht = "C:\Users\angus\Downloads\CORNELL-NEWGEO\Signals\Signals_sub03-tgb.adicht"

% Read adicht file
adicht  = adi.readFile(path_to_adicht);

% Try and get Peso

%% Data inspection
% sel = 1 
% sel = 2; , 
% sel = 3; ; 
% sel = 4; ;  Seems that Peso is wrong 533360
% sel = 5; PCV;  Length 1847640
% sel = 6; , 
% sel = 7; , 
% sel = 8; , 

 ;% Constant comes from the sampling time at the adicht file

%%  SAMPLING FOR PCV
% ABOUT 10 cycles with reasonable Peso variations [-5,-4]
%sel = 5;
%i0 = 1101000-1;
%i1 = 1151000-1;
%time = (0:(i1-i0))*0.0025 ;% Constant comes from the sampling time at the adicht file

% Alternative Paw_high = ~ 20 cmH2O Paw_low ~ 2 cmH2O; Peso ~ [-2,0]
% sel = 8;
% i0 = 1000-1;
% i1 = 31000-1;

%% SAMPLING FOR VCV
% Over 10 cycles, with Peso varying in a reasonable way [-2,2]
% sel = 8;
% i0 = 3951000-1;
% i1 = 3981000-1;

%%

sel = 8;
i0 = 1000-1;
i1 = 31000-1;
time = (0:(i1-i0))*0.0025

Paw = adicht.getChannelByName('Paw');
Paw_data = Paw.getData(sel);
Paw_rdata = Paw_data(i0:i1);

% Pressure-related plot
close(figure(1));
close(figure(2));
figure(1);
plot(time,Paw_rdata);
xlabel("Time (s)")
ylabel("Airway pressure (cmH2O)")
%xlim([0,10])
yyaxis right
Peso = adicht.getChannelByName('Peso');
Peso_data = Peso.getData(sel);
Peso_rdata = Peso_data(i0:i1);
Peso_sdata = smoothdata(Peso_rdata,1,"movmean",8);
Peso_sdata = smoothdata(Peso_sdata,1,"movmedian",16);
plot(time,Peso_sdata);
xlabel("Time (s)")
ylabel("Esophageal pressure (cmH2O)")
%xlim([0,10])
ylim([-5,5])

%% Data selection

sel = 8;  
i0 = 1000-1;
fitter = 191;
i0 = i0 + fitter;
i1 = i0+10001;
time = (0:(i1-i0))*0.0025; % Constant comes from the sampling time at the adicht file

%sel = 11;  % Selected channel for VCV-PEEP10
%i0 = 1580000;
%fitter = 581;
%i0 = i0 + fitter;
%i1 = 1620000-1;
%time = (0:(i1-i0))*0.0025; % Constant comes from the sampling time at the adicht file


%% Airway pressure

Paw = adicht.getChannelByName('Paw');
Paw_data = Paw.getData(sel);
Paw_rdata = Paw_data(i0:i1);

plot(time,Paw_rdata);
xlabel("Time (s)")
ylabel("Airway pressure (cmH2O)")
xlim([0,10])
ylim([0,35])

%% Esophageal pressure

Peso = adicht.getChannelByName('Peso');
Peso_data = Peso.getData(sel);
Peso_rdata = Peso_data(i0:i1);
%Peso_sdata = smoothdata(Peso_rdata,1,"movmean",8);
%Peso_sdata = smoothdata(Peso_sdata,1,"movmedian",16);
Peso_sdata = lowpass(Peso_rdata,0.01);
plot(time,Peso_sdata);
xlabel("Time (s)")
ylabel("Esophageal pressure (cmH2O)")
xlim([0,10])
%ylim([1,4])


%% Esophageal pressure and low-pass filter


y = Peso_rdata(1:4000);
x = time(1:4000);
z1 = lowpass(y,0.01);


close(figure(1));
close(figure(2));
figure(1);
plot(x,z1)
%ylim([0.5,4.5])
%yline(mean(z1),"--","Mean flow")
ylabel("Esophageal pressure (cmH2O)")
xlabel("Time (s)")
%figure(2);
%plot(x,z1)
%ylim([0.5,4.5])
%ylabel("Esophageal pressure (cmH2O)")
%yline(mean(z1),"--","Mean flow")
%xlabel("Time (s)")

%plot(time,lowpass(y,150))
%pspectrum(z1)
%mean(z1)
%(mean(y)-mean(z1))/mean(y)*100

%std(z1)
%% Flow

Flow = adicht.getChannelByName('Flow');
flow_data = Flow.getData(sel);
flow_data = flow_data/60.; % Changing units
correction = -0.005 ;%-0.00946759; % Obtained by measuring the non-zero value of the raw signal in the inspiratory pause
flow_data = flow_data + correction; % Note the correction;
flow_rdata = flow_data(i0:i1);

plot(time,flow_rdata);
xlabel("Time (s)")
ylabel("Flow (L/s)")
xlim([0,10])

%% Volume
close(figure);
figure
volume = transpose(cumtrapz(flow_rdata))*0.0025;
plot(time,volume);
xlim([0,10])
xlabel("Time (s)")
ylabel("Volume (L)")

%% Compute transpulmonar pressure
% Ptp ~= Pao - Peso

Ptp_rdata = Paw_rdata - Peso_rdata;
plot(time,smoothdata(Ptp_rdata,"movmedian",10));

%% Generating a figure to examine both flow and volume simultaneously
close(figure(1));
figure(1);
subset = (time<2.3675*2) .* (time>2.3675)
subset = subset > 0.1
lw = 1.0
plot(time(subset),smoothdata(volume(subset),"movmedian",8),"LineWidth",lw,"Color","b");
alpha 0.2;
ylabel("Volume (L)")
%ylim([-0.05,0.25])
line1 = yline(0.0,"--","End-expiration","Color","b","LineWidth",1.0,"LabelVerticalAlignment","bottom");
line1.FontSize=8


yyaxis right
plot(time(subset), smoothdata(flow_rdata(subset),"movmedian",8),"LineWidth",lw,"Color","r");
xlabel("Time (s)")
ylabel("Flow (L/s)")
line2 = yline(0.0,"--","No flow","Color","r","LineWidth",1.0,"LabelVerticalAlignment","bottom");
line2.FontSize=8


%% Determining average flow
% Determining the mean flow is trickier as the wave is not square

plot(time, smoothdata(flow_rdata,"movmedian",8),"LineWidth",lw,"Color","r");
% This is a single flow wave; smoothed for better visualization

mean_flow = mean(smoothdata(flow_rdata(time<0.4775)));

plot(time(time<0.4775),smoothdata(flow_rdata(time<0.4775)));
yline(mean_flow,"--","Mean flow")
xlabel("Time (s)")
ylabel("Flow (L/s)")


%% BVilla's equations

X = [transpose(volume),flow_rdata,ones(size(flow_rdata))];

A_mid = inv(transpose(X)*X)

%%  BVilla's equations; Respiratory system properties
A = A_mid*transpose(X)*Paw_rdata;
E_rs = A(1); % E, R, P0  % 61.6533 cmH2O/L
C_rs = 1/E_rs*1000;  % 16.2197  mL/cmH2O
R_rs = A(2);  % 9.2008 cmH2O/L/s
PEEP_reg = A(3); % 6.4538 cmH2O

%% BVilla's equations; Chest-wall properties

A = A_mid*transpose(X)*Peso_sdata;
E_cw = A(1); % E, R, P0  % 9.4572 cmH2O/L
C_cw = 1/E_cw*1000;  % 105.7400 mL/cmH2O
R_cw = A(2);  % 0.8223 cmH2O/L/s
Peso_p0_reg = A(3); % -2.0097 cmH2O

%% BVilla's equations; Lung properties 

A = A_mid*transpose(X)*(Paw_rdata-Peso_sdata);
E_L = A(1); % E, R, P0  % 52.1962 cmH2O/L
C_L = 1/E_L*1000;  % 19.1585 mL/cmH2O
R_L = A(2);  % 8.3785 cmH2O/L/s
Ptp_p0_reg = A(3); % 8.4635 cmH2O

%% Export data

path = "C:\Users\angus\Downloads\CORNELL-GEOM\test\Signals\PIG6_APRV.mat";

save(path, "Paw_rdata","flow_rdata","Peso_sdata","volume","time");


%% Generate reconstructed figures

P_aw_reconstructed = E_rs*transpose(volume)+R_rs*flow_rdata+PEEP_reg;
P_eso_reconstructed = E_cw*transpose(volume)+R_cw*flow_rdata+Peso_p0_reg;
P_tp_reconstructed = E_L*transpose(volume)+R_L*flow_rdata+Ptp_p0_reg;

%% Reconstructing airway pressure

close all;
figure(1);
plot(time,Paw_rdata)
hold on;
plot(time,P_aw_reconstructed)
xlim([0,10])
ylim([0,35])
legend("Airway pressure", "Reconstructed signal","location","southwest")
xlabel("Time (s)")
ylabel("Pressure (cmH2O)")

%% Reconstructing esophageal pressure

close all;
figure(1);
plot(time,Peso_sdata)
hold on;
plot(time,P_eso_reconstructed)
xlim([0,10])
ylim([0.5,4.5])
legend("Esophageal pressure", "Reconstructed signal","location","southwest")
xlabel("Time (s)")
ylabel("Pressure (cmH2O)")

%% Reconstructing esophageal pressure

close all;
figure(1);
plot(time,Paw_rdata-Peso_sdata)
hold on;
plot(time,P_tp_reconstructed)
xlim([0,10])
ylim([0,35])
legend("Transpulmonary pressure", "Reconstructed signal","location","southwest")
xlabel("Time (s)")
ylabel("Pressure (cmH2O)")
