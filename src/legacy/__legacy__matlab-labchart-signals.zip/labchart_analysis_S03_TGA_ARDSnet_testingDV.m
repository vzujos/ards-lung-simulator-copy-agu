%% Parameters
path_to_adicht = "C:\Users\angus\Downloads\CORNELL-NEWGEO\Signals\Signals_sub02-tga.adicht";
sel = 14;                          % Selected data section
target_volume = 0.387;            % Target volume in liters
window_length = 1000;            % Samples per window
step = 2000;                      % Step size for scouting
start_idx = 2150000;
end_idx = start_idx+20000;
Fs = 1/0.0025;                    % Sampling frequency [Hz]
dt = 1/Fs;

%% Load file and flow signal
adicht  = adi.readFile(path_to_adicht);
Flow = adicht.getChannelByName('Flow');
flow_data = Flow.getData(sel) / 60;  % Convert to L/s

% Automatic baseline correction using initial samples
baseline_estimate = mean(flow_data(start_idx:start_idx+5000));
flow_data = flow_data - baseline_estimate;

%% Scout windows to find volume closest to target
min_diff = Inf;
best_i0 = NaN;
best_i1 = NaN;
best_volume = [];

for i0 = start_idx:step:(end_idx - window_length)
    i1 = i0 + window_length - 1;

    flow_window = flow_data(i0:i1);
    flow_window = flow_window - mean(flow_window); % extra local correction
    volume_window = cumtrapz(flow_window) * dt;

    max_vol = max(volume_window);
    diff = abs(max_vol - target_volume);

    if diff < min_diff
        min_diff = diff;
        best_i0 = i0;
        best_i1 = i1;
        best_volume = volume_window;
    end
end

%% Results
fprintf("Best window: i0 = %d, i1 = %d\n", best_i0, best_i1);
fprintf("Closest max volume = %.5f (target = %.5f), diff = %.5f\n", ...
    max(best_volume), target_volume, min_diff);

%% Plot best volume
time_best = (0:(best_i1 - best_i0)) * dt;
figure;
plot(time_best, best_volume);
xlabel("Time (s)");
ylabel("Volume (L)");
title("Best Matching Volume Window");
ylim([-0.1 0.5])
